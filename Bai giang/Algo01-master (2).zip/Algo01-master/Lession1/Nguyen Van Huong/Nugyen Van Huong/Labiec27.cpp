#include <stdio.h>
#include <conio.h>

void DoPrintf(int x, char kitu)
{
	for(int i = 1; i <= x; i++)
	{
		printf("%c", kitu);
	}
}
int main()
{
	freopen("Labiec27.txt","r", stdin);
	// chu H nhap chieu cao la so le
	
	int a, b;
	scanf("%d %d", &a,&b);
	
	for(int i = 1; i <= a; i++)
	{
		if(i == (a / 2) + 1)
		{
			DoPrintf(b+2,'*');
		}
		else
		{
			DoPrintf(1,'*');
			DoPrintf(b, ' ');
			DoPrintf(1, '*');
		}
		
		
		
		printf("\n");
	}
	
	
	
	
	
	

	getch();
	return 0;
}
