#include <stdio.h>
#include <conio.h>

int main()
{
	float Diem;
	do
	{
		printf("\nNhap diem : ");
		scanf("%f",&Diem);
		
	}while(Diem <0 || Diem > 10);
	
	
	
	if(Diem >= 9)
	{
		printf("Xuat sac");
	}
	else if(Diem >= 8 && Diem < 9)
	{
		printf("Gioi");
	}
	else if(Diem >= 7 && Diem < 8)
	{
		printf("Kha");
	}
	else if(Diem >= 6 && Diem < 7)
	{
		printf("TBKha");
	}
	else if(Diem >= 5 && Diem < 6)
	{
		printf("TBinh");
	}
	else
	{
		printf("Yeu");
	}
	
	getch();
	return 0;
}
