#include <stdio.h>
#include <conio.h>

int main()
{
	freopen("MamXanh4.txt","r",stdin);
	
	int a,b;
	scanf("%d",&a);
	scanf("%d",&b);
	
	printf("\nSo thu nhat o file la: %d", a);
	printf("\nSo thu hai o file la: %d", b);
	
	getch();
	return 0;
}
