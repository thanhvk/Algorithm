#include <stdio.h>
#include <conio.h>
void DoPrintf(int x, char kitu)
{
	for(int i = 1; i <= x; i++)
	{
		printf("%c", kitu);
	}
}
int main()
{
	freopen("Labiec7.txt","r",stdin);
	
	int n;
	scanf("%d", &n);
	int dem = 1;
	for(int i = 1; i <= n; i++)
	{
		DoPrintf(n - i,' ');
		DoPrintf(dem,'*');
		dem = dem + 2;
		printf("\n");
	}
	
	
	
	

	getch();
	return 0;
}
