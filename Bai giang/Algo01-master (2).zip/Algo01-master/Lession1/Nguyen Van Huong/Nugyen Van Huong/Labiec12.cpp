#include <conio.h>
#include <stdio.h>
#include <math.h>
bool KiemTraSNT(int n)
{
	if(n < 2)
		return false;
	else if(n == 2)
		return true;
	else
		if(n % 2 == 0)
		{
			return false;
		}
		else
		{
			for(int i = 3; i <= sqrt(n); i+= 2)
				{
					if(n % i == 0)
						return false;
				}
		}
	
	return true;
}
int main()
{
	
	for(int i = 1; i < 10 ; i++)
	{
		printf("\n");
		int n;
		scanf("%d",&n);
		
		if(KiemTraSNT(n))
		{
			printf("\n%d la so nguyen to", n);
		}
		else
		{
			printf("\n%d khong la so nguyen to", n);
		}
	}
	
	
	getch();
	return 0;
}
