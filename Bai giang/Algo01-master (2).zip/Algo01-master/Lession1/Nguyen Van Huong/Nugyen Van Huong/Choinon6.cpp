#include <stdio.h>
#include <conio.h>

int main()
{
	freopen("Choinon6.txt", "r", stdin);
	
	int SoGio, LuongGio;
	scanf("%d %d ", &SoGio, &LuongGio);
	int TongTien;
	if(SoGio <= 40)
	{
		TongTien = SoGio * LuongGio;
	}
	else
	{
		TongTien = LuongGio * 40 + LuongGio * (SoGio - 40) * 2;
	}
	printf("Tong tien = %d ", TongTien);
	getch();
	return 0;
}
