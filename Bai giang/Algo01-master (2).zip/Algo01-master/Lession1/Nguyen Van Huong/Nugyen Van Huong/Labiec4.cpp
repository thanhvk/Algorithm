#include <stdio.h>
#include <conio.h>

int main()
{
	freopen("Labiec4.txt","r",stdin);
	for(int i = 1; ; i++)
	{
		int a;
		scanf("%d",&a);	
		if(a % 10 != 0)
		{
			printf("%d ", a);
		}
		else
		{
			break;
		}
	}
	
	

	
	return 0;
}
