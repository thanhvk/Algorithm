#include <stdio.h>
#include <conio.h>
void DoPrintf(int x, char kitu)
{
	for(int i = 1; i <= x; i++)
	{
		printf("%c", kitu);
	}
}
int main()
{
	freopen("Labiec15.txt","r",stdin);
	
	int n;
	scanf("%d", &n);
	
	freopen("Bai15.txt","w",stdout);
	
	DoPrintf(n-1,' ');
	DoPrintf(1,'*');
	printf("\n");
	int dem = 1;
	for(int i = 2; i <= n; i++)
	{
		DoPrintf(n - i,' ');
	 	DoPrintf(1,'*');
		DoPrintf(dem, ' ');
		dem+= 2;
		DoPrintf(1,'*');
		printf("\n");
	}
	DoPrintf(2*n-1,'*');
	
	
	
	

	getch();
	return 0;
}
