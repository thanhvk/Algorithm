#include <stdio.h>
#include <conio.h>

int main()
{
	int a;
	printf("Nhap so nguyen : ");
	scanf("%d",&a);
	
	printf("Binh phuong cua %d la : %d", a, a*a);
	printf("\nLap phuong cua %d la : %d", a, a*a*a);
	
	
	getch();
	return 0;
}
