#include <stdio.h>
#include <conio.h>

int main()
{
	int a, b ,c;
	scanf("%d %d %d", &a, &b, &c);
	
	if(c >= b && c >= a)
	{
		printf("\n%d la so lon nhat ",c);
	}
	else if(b >= c && b >= a)
	{
		printf("\n%d la so lon nhat ",b);
	}
	else if(a >=b && a >= c)
	{
		printf("\n%d la so lon nhat ",a);
	}
	
	getch();
	return 0;
}
