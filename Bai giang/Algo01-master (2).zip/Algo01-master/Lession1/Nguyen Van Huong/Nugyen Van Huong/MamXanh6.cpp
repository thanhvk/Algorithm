#include <stdio.h>
#include <conio.h>

int main()
{
	float Pi = 3.14;

	float bankinh;
	scanf("%f",&bankinh);
	
	float DienTich = bankinh * bankinh * Pi;
	printf("Dien tich hinh tron co ban kinh %f la : %f",bankinh,DienTich);
	getch();
	return 0;
}
