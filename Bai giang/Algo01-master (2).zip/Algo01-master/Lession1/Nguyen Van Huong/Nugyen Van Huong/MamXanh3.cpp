#include <stdio.h>
#include <conio.h>

int main()
{
	freopen("MamXanh3.txt","r",stdin);
	
	int a;
	scanf("%d",&a);
	
	printf("So o file la: %d", a);
	getch();
	return 0;
}
