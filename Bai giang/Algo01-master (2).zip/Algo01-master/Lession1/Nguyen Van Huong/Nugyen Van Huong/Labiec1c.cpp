#include <stdio.h>
#include <conio.h>

int main()
{
	int a, b;
	do
	{
		scanf("%d %d",&a,&b);
		
	}while(a > 100 || b > 100);

	
	for(int i = a; i <= b; i++)
	{
		if(i % 2 == 0)
			printf("%d\n",i);
	}
	return 0;
}
