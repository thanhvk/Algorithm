#include <stdio.h>
#include <conio.h>

int main()
{
	int a, b;
	scanf("%d",&a);
	scanf("%d",&b);
	
	if(a == b)
	{
		printf("%d bang %d",a,b);
	}
	else if(a < b)
	{
		printf("%d nho hon %d",a,b);
		
	}
	else
	{
		printf("%d lon hon %d",a,b);
	}
	
	
	getch();
	return 0;
}
