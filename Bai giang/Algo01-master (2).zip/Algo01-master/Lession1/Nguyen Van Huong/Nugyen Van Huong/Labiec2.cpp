#include <stdio.h>
#include <conio.h>

int main()
{
	int n;
	scanf("%d",&n);
	int tong = 0;
	for(int i = 0; i <= n; i++)
	{
		if(i % 2 != 0)
			tong += i;
	}
	printf("Tong = %d", tong);
	return 0;
}
