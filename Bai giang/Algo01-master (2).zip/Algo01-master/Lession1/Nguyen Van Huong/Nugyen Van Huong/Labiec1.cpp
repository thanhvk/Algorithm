#include <stdio.h>
#include <conio.h>

int main()
{
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n; i++)
	{
		printf("Vi du su dung vong lap for\n");
	}
	
	return 0;
}
