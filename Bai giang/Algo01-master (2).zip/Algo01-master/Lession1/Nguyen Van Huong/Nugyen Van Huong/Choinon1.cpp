#include <stdio.h>
#include <conio.h>

int main()
{

	int a, b;
	scanf("%d",&a);
	scanf("%d",&b);
	
	//int Max = a > b ? a : b;
	int Max = 0;
	if(a > b)
	{
		Max = a;
	}
	else
	{
		Max = b;
	}
	
	printf("\nSo lon nhat = %d", Max);
	
	getch();
	return 0;
}
