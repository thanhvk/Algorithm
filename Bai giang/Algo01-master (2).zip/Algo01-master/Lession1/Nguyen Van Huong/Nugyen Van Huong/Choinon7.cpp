#include <stdio.h>
#include <conio.h>
#include <math.h>
int main()
{
	
	// 3 canh tam giac
	// S = can(p *(p - a)*(p - b) * (p - c))
	int a, b ,c;
	scanf("%d %d %d", &a, &b,&c);
	float DienTich;
	float p = (float)(a + b + c) / 2;
	if(a + b > c || a + c > b || b + c > a)
	{
		DienTich = sqrt(p* (p -a)*(p - b)* (p -c));
		printf("Dien tich =  %f", DienTich);
	}
	else
	{
		printf("\nKhong phai tam giac !");
	}
	
	
	
	getch();
	return 0;
}
