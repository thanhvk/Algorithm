#include <stdio.h>
#include <conio.h>

int main()
{
	freopen("Labiec21.txt","r", stdin);
	int n = 10;
	int Min;
	for(int i = 0; i < 10; i++)
	{
		int a;
		scanf("%d", &a);
		Min = a;
	}// gan gia tri dau = min;
	
	for(int i = 1; i < 10; i++)
	{
		int b;
		scanf("%d", &b);
		if(b < Min)
		{
			Min = b;
		}
	}
	printf("Min = %d", Min);
	
	
	
	
	
	

	getch();
	return 0;
}
