#include <stdio.h>
#include <conio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int tong = 0;
	for(int i = 1; i <= n; i++)
	{
		tong += i;
	}
	printf("\n%d", tong);
	return 0;
}
