#include <stdio.h>
#include <conio.h>
#define KW0    50 * 230
#define KW50   50 * 480
#define KW100  50 * 700

int main()
{
	freopen("Choinon10.txt","r", stdin);
	
	float TienDien = 1000;
	int KW;
	scanf("%d", &KW);
	
	if(KW < 50)
	{
		TienDien += KW * 230;
	}
	else if(KW < 100)
	{
		TienDien += KW0 + (KW - 50)* 480;
	}
	else if(KW < 150)
	{
		TienDien += KW0 + KW50 + (KW - 100)* 700;
	}
	else
	{
		TienDien += KW0 + KW50 + KW100 + (KW - 150)* 900;
	}
	printf("Tong tien dien : %f", TienDien);
	getch();
	return 0;
}
