#include <stdio.h>
#include <conio.h>

int main()
{
	// doi giay thanh gio:phut:giay
	int gio = 0, phut = 0;
	freopen("MamXanh9.txt","r", stdin);
	int giay;
	do
	{
		scanf("%d",&giay);
		if(giay < 0 || giay > 86399)
		{
			printf("Tu 0 -> 86399");
		}
	}while(giay < 0 || giay > 86399);
	
	if(giay >= 60)
	{
		int temp = giay / 60;
		giay = giay % 60;
		phut = phut + temp;
		
		if(phut >= 60)
		{
			int temp = phut / 60;
			phut = phut % 60;
			gio = gio + temp;
		}
	}

	printf("%d: %d: %d", gio, phut, giay);
	
	
	getch();
	return 0;
}
