#include <stdio.h>
#include <conio.h>

int main()
{
	printf("Hello ");
	printf("\nCong hoa xa hoi chu nghia Viet Nam");
	printf("\nDoc lap * Tu do * Hanh Phuc");
	getch();
	return 0;
}
