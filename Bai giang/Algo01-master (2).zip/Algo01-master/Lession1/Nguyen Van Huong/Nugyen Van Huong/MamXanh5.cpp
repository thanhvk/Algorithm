#include <stdio.h>
#include <conio.h>

int main()
{
	int a,b;
	scanf("%d",&a);
	scanf("%d",&b);
	
	printf("Tong hai so la: %d",a+b);

	
	getch();
	return 0;
}
