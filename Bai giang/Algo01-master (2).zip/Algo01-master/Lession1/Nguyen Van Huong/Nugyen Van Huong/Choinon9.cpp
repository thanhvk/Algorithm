#include <stdio.h>
#include <conio.h>
int main()
{
	int a, b ,c;
	scanf("%d %d %d", &a, &b,&c);
	
	int Min = a < b ? a : b;
	int Max = a > b ? a : b;
	
	if(c >= Max)
	{
		printf("%d %d %d", Min, Max, c);
	}
	else if(c <= Min)
	{
		printf("%d %d %d",c, Min, Max);
	}
	else
	{
		printf("%d %d %d", Min,c, Max);
	}
	

	
	getch();
	return 0;
}
