#include <stdio.h>
#include <conio.h>
int main()
{
	freopen("Choinon8.txt", "r",stdin);
	
	int a;
	scanf("%d", &a);
	
	if(a < 0)
	{
		printf("%d la so am", a);
	}
	else
	{
		if(a % 2 == 0)
		{
			printf("%d la so chan ",a);
		}
		else
		{
			printf("%d la so le ",a);
		}
		
	}

	
	getch();
	return 0;
}
