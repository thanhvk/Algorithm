#include <stdio.h>
#include <conio.h>

void DoPrintf(int x, char kitu)
{
	for(int i = 1; i <= x; i++)
	{
		printf("%c", kitu);
	}
}
int main()
{
	freopen("Labiec41.txt","r", stdin);
	
	int n;
	scanf("%d", &n);
	
	int dem = n - 1;
	// in dong dau
	DoPrintf(1,'*');
	DoPrintf(dem,' ');
	DoPrintf(1,'*');
	printf("\n");
	
	for(int i = 2; i <= n / 2;i++)
	{
		dem = dem - 2;
		DoPrintf(i,'*');
		DoPrintf(dem,' ');
		DoPrintf(2*i - 1,'*');
		printf("\n");
	}
	DoPrintf((n / 2 + 1) + n,'*');
	printf("\n");
	for(int i = n/2; i >= 1; i--)
	{
		DoPrintf(i,'*');
		DoPrintf(dem,' ');
		DoPrintf(2*i - 1,'*');
		dem = dem + 2;
		printf("\n");
	}		
	
	
	
	
	
	

	getch();
	return 0;
}
