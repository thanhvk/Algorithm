#include <stdio.h>
#include <conio.h>

int main()
{
	int n;
	do
	{
		scanf("%d", &n);
		
	}while(n < 0 || n > 10000);
	
	int tong = 0;
	
	while(n != 0)
	{
		int temp = n % 10;
		tong += temp;
		n = n / 10;
	}
	printf("Tong = %d", tong);
	
	

	getch();
	return 0;
}
