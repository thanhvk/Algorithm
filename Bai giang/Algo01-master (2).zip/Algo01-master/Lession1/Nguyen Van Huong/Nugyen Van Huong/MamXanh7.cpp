#include <stdio.h>
#include <conio.h>

int main()
{
	// Hinh cau
	float Pi = 3.14;
	float bankinh;
	scanf("%f",&bankinh);
	
	float Dientich = 4 * Pi * bankinh * bankinh;
	float Thetich = ((float)4 / 3)*Pi *bankinh * bankinh*bankinh;
	
	printf("Dien tich hinh cau la : %f",Dientich);
	printf("\nThe tich hinh cau la : %f", Thetich);
	
	
	getch();
	return 0;
}
