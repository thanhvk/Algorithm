#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("mamxanh3.inp.txt","r",stdin);
	freopen("mamxanh3.out.txt","w",stdout);

	int a;
	
	scanf("%d",&a);
	printf("%d",a);
	
	return 0;
}
