#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int h,i,j;
    
	scanf("%d",&h);

    for(i=h;i>=1;printf("\n"),i--)
        for(j=1;j<=(2*h-1);j++)
            if(j>=i && j<=(2*h-i))printf("*");
            else printf(" ");

    return 0;
}
