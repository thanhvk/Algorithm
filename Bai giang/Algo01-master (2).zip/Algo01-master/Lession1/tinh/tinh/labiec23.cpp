#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int n,a,i,x1,x2,x3,x4;
    
	scanf("%d",&n);

    for(i=0;i<n;i++)
        {
            scanf("%d",&a);
            if(a==10000)
                {printf("1\n");continue;}
            
			x1=a/1000;
            x2=(a-x1*1000)/100;
            x3=(a-x1*1000-x2*100)/10;
            x4=a-x1*1000-x2*100-x3*10;
            
			printf("%d\n",x1+x2+x3+x4);
        }

    return 0;
}
