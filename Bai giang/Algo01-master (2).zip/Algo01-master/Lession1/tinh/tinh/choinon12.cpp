#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("choinon12.inp.txt","r",stdin);
    freopen("choinon12.out.txt","w",stdout);

    int a,b,c,delta;
    
	scanf("%d %d %d",&a,&b,&c);

    delta = b*b-4*a*c;
    if(delta<0)printf("Phuong trinh vo nghiem");
    else if(delta==0)printf("Phuong trinh co nghiem kep x1=x2=%.2f",-(float)b/a/2);
    else printf("Phuong trinh co 2 nghiem phan biet x1=%.2f, x2=%.2f",(-b+sqrt(delta))/a/2,(-b-sqrt(delta))/a/2);

    return 0;
}
