#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int i;

    do
    {
        scanf("%d",&i);
        if(i%10!=0)printf("%d ",i);
        else break;
    }
    while(1);

    return 0;
}
