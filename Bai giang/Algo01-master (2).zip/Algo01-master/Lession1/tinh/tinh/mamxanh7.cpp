/*dien tich, the tich hinh cau*/
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define pi 3.14

using namespace std;

int main()
{
    int r;
    float s,v;
    
    scanf("%d",&r);
    s=pi*pow(r,2);
    v=4*pi/3*pow(r,3);
    printf("Dien tich hinh cau la %.2f\n",s);
    printf("The tich hinh cau la %.2f\n",v);
    
	return 0;
}
