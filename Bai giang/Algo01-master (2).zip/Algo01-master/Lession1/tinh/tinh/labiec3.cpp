#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int n,i,t,tong=0;

    scanf("%d",&n);
    
	for(i=1;i<=n;i++)
    {
        scanf("%d",&t);
        tong+=t;
    }
	printf("%d\n",tong);
    
	return 0;
}
