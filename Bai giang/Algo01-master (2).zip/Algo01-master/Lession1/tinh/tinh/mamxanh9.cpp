/* s -> hh:mm:ss */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int s,hh,mm,ss;
    scanf("%d",&s);

    hh=s/3600;
    mm=(s%3600)/60;
    ss=s%60;

    printf("%02d:%02d:%02d\n",hh,mm,ss);
    
	return 0;
}
