#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("choinon10.inp.txt","r",stdin);
    freopen("choinon10.out.txt","w",stdout);

    int t;
    
	scanf("%d",&t);

    if(t>=0 && t<=50) printf("%d",1000+t*230);
    else if(t>50 && t<=100) printf("%d",1000+50*230+(t-50)*480);
    else if(t>100 && t<=150) printf("%d",1000+50*230+50*480+(t-100)*700);
    else printf("%d",1000+50*230+50*480+50*700+(t-150)*900);

    return 0;
}
