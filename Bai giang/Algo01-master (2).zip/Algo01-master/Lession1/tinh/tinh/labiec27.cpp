#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int i,j,w,h;
    
	scanf("%d%d",&w,&h);

    for(i=1;i<=h;printf("\n"),i++)
        for(j=1;j<=w;j++)
        {
            if(i==1)printf("*");
            else if(j==(w/2+1))printf("*");
            else printf(" ");
        }

    return 0;
}
