#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    float tb;
    
    scanf("%f",&tb);
    
	if(tb>=9 && tb<=10)printf("Xuat sac\n");
    else if(tb>=8 && tb<9)printf("Gioi\n");
    else if(tb>=7 && tb<8)printf("Kha\n");
    else if(tb>=6 && tb<7)printf("TB Kha\n");
    else if(tb>=5 && tb<6)printf("TB\n");
    else if(tb>=0 && tb<5)printf("Yeu\n");
    else printf("Diem khong hop le");
    
	return 0;
}
