#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("choinon9.inp.txt","r",stdin);
    freopen("choinon9.out.txt","w",stdout);

    int a;
    
	scanf("%d",&a);

    if(a>=0)
        if(a%2==0)printf("%d la so chan",a);
        else printf("%d la so le",a);
    else printf("%d la so am",a);

    return 0;
}
