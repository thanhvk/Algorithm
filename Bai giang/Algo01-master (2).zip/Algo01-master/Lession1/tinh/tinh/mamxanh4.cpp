#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("mamxanh4.inp.txt","r",stdin);
	freopen("mamxanh4.out.txt","w",stdout);

	int a,b;
	
	scanf("%d %d",&a,&b);
	printf("So thu 1 trong file la %d \nSo thu 2 trong file la %d",a,b);
	
	return 0;
}
