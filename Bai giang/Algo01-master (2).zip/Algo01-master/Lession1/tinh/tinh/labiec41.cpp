#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("labiec41.inp.txt","r",stdin);
    freopen("labiec41.out.txt","w",stdout);

    int h,p,i,j;
    
	scanf("%d",&h);

    p=h/2+1;
    for(i=1;i<=h;printf("\n"),i++)
        {
            if(abs(p-i)==0)
                for(j=1;j<=(p-abs(p-i)-1);j++)printf("*");
            else
                for(j=1;j<=(p-abs(p-i));j++)printf("*");
            for(j=1;j<=(abs(p-i)*2-1);j++)printf(" ");
            for(j=1;j<=((p-abs(p-i))*2-1);j++)printf("*");
        }
    
	return 0;
}
