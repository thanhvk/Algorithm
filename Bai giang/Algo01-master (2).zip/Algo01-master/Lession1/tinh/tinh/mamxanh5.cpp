#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("mamxanh5.inp.txt","r",stdin);
	freopen("mamxanh5.out.txt","w",stdout);

	int a,b;
	
	scanf("%d %d",&a,&b);
	printf("Tong 2 so la %d",a+b);
	
	return 0;
}
