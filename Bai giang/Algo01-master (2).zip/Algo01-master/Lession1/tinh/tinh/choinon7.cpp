/* kiem tra 3 canh tam giac va tinh dien tich */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int a,b,c;
    float p,s;
    
    scanf("%d %d %d",&a,&b,&c);

    if(a+b>c && a+c>b && b+c>a)
    {
        p=(a+b+c)/(float)2;
        s=sqrt(p*(p-a)*(p-b)*(p-c));
        printf("dien tich = %.2f\n",s);
    }
    else printf("%d,%d,%d khong phai tam giac",a,b,c);

    return 0;
}
