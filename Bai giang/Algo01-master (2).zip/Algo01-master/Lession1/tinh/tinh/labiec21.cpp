#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int n,m,a,i,j,x,t;

    scanf("%d",&n);
    
	for(i=1;i<=n;i++)
        {
            scanf("%d",&m);
            for(j=1;j<=m;j++)
                {
                    scanf("%d",&a);
                    if(j==1)
                        {x=a;t=1;continue;}
                    if(a<x)
                        {x=a;t=1;continue;}
                    if(a==x)t++;
                }
            printf("%d %d\n",x,t);
        }

    return 0;
}
