#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int a,b,i;
    
	scanf("%d%d",&a,&b);

    for(i=a;i<=b;i++)if(i%2==0)printf("%d\n",i);

    return 0;
}
