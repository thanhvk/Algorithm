#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define pi 3.14

using namespace std;

int main()
{
    int r;
    
	scanf("%d",&r);
    printf("Dien tich hinh tron co ban kinh %d = %.2f",r,r*r*pi);
    
	return 0;
}
