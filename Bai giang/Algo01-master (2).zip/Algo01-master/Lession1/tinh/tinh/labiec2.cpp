#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int n,i,tong=0;
    
	scanf("%d",&n);

    for(i=1;i<=n;i+=2)tong+=i;
    printf("%d\n",tong);

    return 0;
}
