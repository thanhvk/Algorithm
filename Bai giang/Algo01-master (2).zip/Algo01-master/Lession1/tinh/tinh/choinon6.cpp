#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("choinon6.inp.txt","r",stdin);
    freopen("choinon6.out.txt","w",stdout);

    int h,s;
    
	scanf("%d %d",&h,&s);

    if(h<=40)printf("%d",h*s);
    else printf("%d",(h-40)*2*s+40*s);
}
