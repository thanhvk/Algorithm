#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    int n,a,i,j,x;

    scanf("%d",&n);
    
	for(i=1;i<=n;i++)
    {
        scanf("%d",&a);
        for(x=1,j=2;j<=sqrt(a);j++)
            {
                if(a%j==0)
                    {x=0; break;}
            }
        if(x==1)printf("%d la so nguyen to\n",a);
        else printf("%d khong phai la so nguyen to\n",a);
    }

    return 0;
}
