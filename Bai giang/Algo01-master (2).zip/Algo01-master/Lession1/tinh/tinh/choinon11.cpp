#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
    freopen("choinon11.inp.txt","r",stdin);
    freopen("choinon11.out.txt","w",stdout);

    int a,b;
    
    scanf("%d %d",&a,&b);

    if(a==0 && b!=0)printf("Phuong trinh vo nghiem");
    else if(a==0 && b==0)printf("Phuong trinh vo so nghiem");
    else printf("Phuong trinh co 1 nghiem x = %.2f",-(float)b/a);

    return 0;
}
