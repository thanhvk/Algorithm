//
//  main.cpp
//  mamxanh1
//
//  Created by Bach Duong on 3/20/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

using namespace std;

int main(int argc, const char * argv[]) {
    // insert code here...

    printf("Hello World");
    return 0;
}
