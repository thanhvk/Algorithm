//
//  main.cpp
//  choinon4
//
//  Created by Bach Duong on 3/21/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main(int argc, const char * argv[]) {
    float a;
    printf("Nhap vao diem : ");
    scanf("%f", &a);
    
    if (a >= 9) {
        printf("Xuat xac");
        return 0;
    }
    
    if (a <= 9 && a > 8) {
        printf("Gioi");
        return 0;
    }
    
    if (a <= 8 && a > 7) {
        printf("Kha");
        return 0;
    }
    
    if (a <= 7 && a >= 6) {
        printf("TBKha");
        return 0;
    }
    
    if (a <= 6 && a > 5) {
        printf("Tbinh");
        return 0;
    }
    
    printf("Yeu");
    return 0;
}
