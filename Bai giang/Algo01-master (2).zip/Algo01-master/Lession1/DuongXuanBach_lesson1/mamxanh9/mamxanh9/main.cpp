//
//  main.cpp
//  mamxanh9
//
//  Created by Bach Duong on 3/20/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main() {
    // insert code here...
    printf("Nhap vao 1 so giay tu 0 den 86399: ");
    int n;
    scanf("%d", &n);
    int h, total_m, m, s;
    
    while (n > 0 && n <= 86399) {
        total_m = n / 60;
        s = n % 60;
        
        h = total_m / 60;
        m = total_m % 60;
        
        printf("gio : %d\n", h);
        printf("phut : %d\n", m);
        printf("giay : %d\n", s);
        printf("gio phut giay: %d:%d:%d", h, m, s);
        
        return 0;
    }
    
    return 0;
}
