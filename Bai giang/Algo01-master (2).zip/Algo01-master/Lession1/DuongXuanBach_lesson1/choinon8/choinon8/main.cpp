//
//  main.cpp
//  choinon8
//
//  Created by Bach Duong on 3/22/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
#include<math.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    int a, b, c;
    
    printf("Nhap 3 so duong: ");
    scanf("%d %d %d", &a, &b, &c);
    
    float tb_ab, tb_bc;
    
    tb_ab = (a+b) / 2.0;
    tb_bc = (b+c) / 2.0;
    
    if(tb_ab >= tb_bc) {
        if(a >= b){
            printf("Danh sach : %d %d %d", a , b, c);
        } else {
            printf("Danh sach : %d %d %d", b, a, c);
        }
    } else {
        if(b >= c){
            printf("Danh sach : %d %d %d", b , c, a);
        } else {
            printf("Danh sach : %d %d %d", c , b, a);
        }
    }
    
    return 0;
}
