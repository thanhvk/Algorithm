//
//  main.cpp
//  mamxanh7
//
//  Created by Bach Duong on 3/20/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main() {
    // insert code here...
    printf("Nhap vao ban kinh hinh cau :");
    int n;
    float pi = 3.14;
    
    scanf("%d", &n);
    
    printf("Dien tich hinh cau co ban kinh %d la %f\n", n, 4 * pi * n * n);
    printf("The tich hinh cau co ban kinh %d la %f\n", n, 4.0/3 * pi * n * n);

    return 0;
}