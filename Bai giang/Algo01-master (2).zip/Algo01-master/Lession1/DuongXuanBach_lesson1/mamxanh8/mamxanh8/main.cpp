//
//  main.cpp
//  mamxanh8
//
//  Created by Bach Duong on 3/20/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main() {
    
    printf("Nhap vao so nguyen bat ky : ");
    int n;
    
    scanf("%d", &n);
    printf("Binh phuong cua %d la %d\n", n, n*n);
    printf("Lap phuong cua %d la %d\n", n, n*n*n);
   
    return 0;
}
