//
//  main.cpp
//  mamxanh3
//
//  Created by Bach Duong on 3/20/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

using namespace std;

int main() {
    // insert code here...
    freopen("mamxanh3.inp", "r", stdin);
    
    int a;
    scanf("%d", &a);
    
    printf("so trong file la %d\n", a);
    
    
    return 0;
}
