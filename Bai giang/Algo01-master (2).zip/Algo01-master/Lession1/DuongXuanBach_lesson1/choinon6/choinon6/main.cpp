//
//  main.cpp
//  choinon6
//
//  Created by Bach Duong on 3/21/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    
    int hour, salaryPerHour, salary;
    
    printf("Nhap vao so gio lam: ");
    scanf("%d", &hour);
    
    printf("Nhap vao luong tren gio: ");
    scanf("%d", &salaryPerHour);
    
    salary = (hour > 40) ? ( ((hour - 40)*2 + 40) * salaryPerHour) : (hour * salaryPerHour);
    
    printf("Luong thang : %d", salary);
    
    return 0;
}
