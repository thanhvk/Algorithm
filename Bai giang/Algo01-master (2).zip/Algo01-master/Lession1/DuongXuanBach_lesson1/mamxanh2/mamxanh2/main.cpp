//
//  main.cpp
//  mamxanh2
//
//  Created by Bach Duong on 3/20/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello\n");
    printf("Cong Hoa Xa Hoi Chu Nghia Viet Nam\n");
    printf("Doc lap * Tu do * Hanh Phuc");
    return 0;
}
