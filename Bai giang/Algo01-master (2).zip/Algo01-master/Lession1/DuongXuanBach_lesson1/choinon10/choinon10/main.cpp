//
//  main.cpp
//  choinon10
//
//  Created by Bach Duong on 3/22/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
#include<math.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    float used;
    
    freopen("choinon10.inp", "r", stdin);
    scanf("%f", &used);
    
    float basic, over, over_price, all;
    basic = 50 * 230;
    
    if(used <= 50){
        over = 0;
        
        over_price = 0;
    } else {
        over = used - 50;
        if(over <=50){
            over_price = 480;
        } else if (over > 50 && over < 100){
            over_price = 700;
        } else {
            over_price = 900;
        }
    }
    
    all = 1000 + basic + over * over_price;
    
    printf("Tien dien voi cong thuc : 1000 + %f + %f * %f la %f", basic, over, over_price, all);
    
    return 0;
}
