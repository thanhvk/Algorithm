//
//  main.cpp
//  mamxanh4
//
//  Created by Bach Duong on 3/21/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    freopen("mamxanh4.inp", "r", stdin);
    
    int a, b;
    scanf("%d %d", &a, &b);
    
    printf("So thu nhat o file la %d\n", a);
    printf("So thu hai o file la %d\n", b);
    
    return 0;
}
