//
//  main.cpp
//  choinon12
//
//  Created by Bach Duong on 3/22/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
#include<math.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    
    int a, b, c;
    
    int alpha;
    
    freopen("choinon12.inp", "r", stdin);
    
    scanf("%d %d %d", &a, &b, &c);
    if (a == 0 && b == 0 && c == 0){
        printf("vo so nghiem");
        return 0;
    }
    
    alpha = (b * b) - 4 * a * c;
    
    if (alpha < 0){
        printf("vo nghiem");
    } else if (alpha == 0) {
        printf("2 nghiem kep: %f, %f", (float)(-b / (2 * a)), (float)(-b / (2 * a)) );
    } else {
        printf("2 nghiem phan biet: %f, %f", (float)( (-b + sqrt(alpha)) / (2 * a)), (float)( (-b - sqrt(alpha)) / (2 * a)) );
    }
    
    return 0;
}
