//
//  main.cpp
//  choinon9
//
//  Created by Bach Duong on 3/22/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
#include<math.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    
    freopen("choinon9.inp", "r", stdin);
    int n;
    scanf("%d", &n);
    
    if (n >= 0){
        if (n % 2 == 0){
            printf("n la so chan");
        } else {
            printf("n la so le");
        }
    } else {
        printf("n la so am");
    }
    
    return 0;
}
