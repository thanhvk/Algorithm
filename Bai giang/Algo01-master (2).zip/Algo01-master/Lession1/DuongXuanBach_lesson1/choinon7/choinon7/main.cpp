//
//  main.cpp
//  choinon7
//
//  Created by Bach Duong on 3/21/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
#include<math.h>

int main(int argc, const char * argv[]) {
    // insert code here...

    int a, b, c;
    printf("Nhap 3 so nguyen duong: ");
    scanf("%d %d %d", &a, &b, &c);
    
    if ((a + b > c) && (a + c > b) && (b + c > a)) {
        double s, p;
        
        p = (a + b + c) / 2.0;
        
        s = sqrt( p * (p-a) * (p-b) * (p-c) );
        
        printf("%d %d %d la 3 canh cua tam giac voi dien tich la %f", a, b, c, s);
    } else {
        printf("Khong phai 3 canh tam giac");
    }
    
    return 0;
}