//
//  main.cpp
//  choinon11
//
//  Created by Bach Duong on 3/22/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
#include<math.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    
    int a, b;
    
    freopen("choinon11.inp", "r", stdin);
    
    scanf("%d %d", &a, &b);
    
    if(a == 0 && b == 0){
        printf("vo so nghiem");
        return 0;
    } else if (a == 0){
        printf("vo nghiem");
        return 0;
    } else {
        printf("1 nghiem %f", (float)(0-b)/a);
        return 0;
    }
    
    
    return 0;
}
