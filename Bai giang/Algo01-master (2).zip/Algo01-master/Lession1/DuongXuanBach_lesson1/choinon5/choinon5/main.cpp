//
//  main.cpp
//  choinon5
//
//  Created by Bach Duong on 3/21/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main(int argc, const char * argv[]) {
    int a, b, c, max;
    
    printf("Nhap vao 3 so nguyen : \n");
    scanf("%d %d %d", &a, &b, &c);
    
    max = (a >= b) ? a : b;
    
    max = (c >= max) ? c : max;
    
    printf("So lon nhat la %d", max);
    return 0;
}
