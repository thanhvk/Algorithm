//
//  main.cpp
//  choinon3
//
//  Created by Bach Duong on 3/21/16.
//  Copyright © 2016 Bach Duong. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main(int argc, const char * argv[]) {
    
    int a, b;
    printf("Nhap vao 2 so nguyen : \n");
    scanf("%d %d", &a, &b);
    
    if (a == b) {
        printf("2 so bang nhau");
        return 0;
    }
    if (a < b){
        printf("So lon hon la %d", b);
    } else {
        printf("So lon hon la %d", a);
    }
    return 0;
}
