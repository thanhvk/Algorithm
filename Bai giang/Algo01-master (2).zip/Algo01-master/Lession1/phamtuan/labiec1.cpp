#include <iostream>
#include  <fstream>
#include  <string.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <conio.h>

using namespace std;

int main(){
    freopen("labiec1.inp","r",stdin);
    int num;
    scanf("%d",&num);
    for(int i = 0; i < num; i++){
        printf("du su dung vong lap for \n");
    }
    return 0;
}
