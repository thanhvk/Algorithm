#include <iostream>
#include  <fstream>
#include  <string.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <conio.h>
using namespace std;

int main(){
    float pi, r, s;
    pi = 3.14;
    scanf("%f", &r);
    s = r * r * pi;
    printf("Ket qua %f",s);
    return 0;
}
