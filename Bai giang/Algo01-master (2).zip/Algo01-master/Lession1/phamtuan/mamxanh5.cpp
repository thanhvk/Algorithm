#include <iostream>
#include  <fstream>
#include  <string.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <conio.h>

using namespace std;

int main(){
    freopen("mamxanh5.inp","r",stdin);
    int number1, number2;
    scanf("%d %d",&number1,&number2);
    printf("Ket qua %d + %d : %d",number1,number2,number1 + number2);
    return 0;
}
