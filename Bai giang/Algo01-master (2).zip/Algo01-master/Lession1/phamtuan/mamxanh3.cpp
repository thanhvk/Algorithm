#include <iostream>
#include  <fstream>
#include  <string.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <conio.h>
using namespace std;

int main(){
    freopen("mamxanh3.inp","r",stdin);
    int number;
    scanf("%d",&number);
    printf("So nhap vao la %d", number);
    return 0;
}
