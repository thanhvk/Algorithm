#include <iostream>
#include  <fstream>
#include  <string.h>
#include  <stdio.h>
#include  <stdlib.h>
#include  <conio.h>
using namespace std;

int main(){
    freopen("mamxanh4.inp","r",stdin);
    int number1, number2;
    scanf("%d %d",&number1,&number2);
    printf("So nhap vao dau tien la %d \n", number1);
    printf("So nhap vao thu hai la %d \n", number2);
    return 0;
}
