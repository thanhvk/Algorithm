//
//  main.cpp
//  MaxNumber1
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Find max number
void exNo10() {
    
    int so1=0, so2=0;
    
    std::cout << "-----------Bai 10------------\n";
    std::cout << "Tim max 2 so nguyen\n";
    
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);
    
    if (so1<so2) {
        printf("So lon nhat = %d\n",so2);
    } else {
        if (so1 == so2) {
            printf("Hai so bang nhau = %d\n",so2);
        }
        else {
            printf("So lon nhat = %d\n",so1);
        }
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo10();
    return 0;
}
