//
//  main.cpp
//  Sum2Int
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate sum of 2 number
void exNo5() {
    
    std::cout << "-----------Bai 5------------\n";
    std::cout << "Tinh tong 2 so nguyen\n";
    int so1;
    int so2;
    int tong2so = 0;
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);
    
    tong2so = so1 + so2;
    
    printf("Tong 2 so la: %d\n", tong2so);
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo5();
    return 0;
}
