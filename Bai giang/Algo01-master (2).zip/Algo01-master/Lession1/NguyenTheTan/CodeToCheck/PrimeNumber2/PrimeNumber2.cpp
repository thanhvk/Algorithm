//
//  main.cpp
//  PrimeNumber2
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>


//Check a number is prime number or not
bool isPrimeNumber(int n) {
    
    for (int i=2; i<n; i++) {
        if (n % i == 0) {
            return false;
            break;
        }
    }
    
    return true;
}

//check prime number for N numbers
void exNo36() {
    int n=0, sonhap=0;
    
    printf("Nhap n:");
    scanf("%d",&n);
    if (n>0 && n<100) {
        for (int i=0; i<n; i++) {
            printf("Nhap so can kiem tra:");
            scanf("%d",&sonhap);
            
            if (isPrimeNumber(sonhap)) {
                printf("%d la so nguyen to\n",sonhap);
            } else {
                printf("%d khong phai la so nguyen to\n",sonhap);
            }
            
        }
    } else {
        printf("So %d khong hop le\n",n);
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo36();
    return 0;
}
