//
//  main.cpp
//  FoorLoop
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//using for loop
void exNo22() {
    int n=0;
    std::cout << "Vi du su dung vong lap FOR\n";
    std::cout << "Nhap so n=";
    scanf("%d",&n);
    
    for (int i=0;i<n;i++) {
        printf("Dung vong lap FOR lap lan thu %d\n",i);
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo22();
    return 0;
}
