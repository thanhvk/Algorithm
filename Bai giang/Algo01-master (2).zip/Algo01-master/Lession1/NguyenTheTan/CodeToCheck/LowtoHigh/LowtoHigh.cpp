//
//  main.cpp
//  LowtoHigh
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//low to high
void exNo17() {
    int min=0,mid=0,max=0,sonhap=0;
    
    std::cout << "-----------Bai 17------------\n";
    for (int i=0;i<3;i++) {
        printf("Nhap so thu %d:",i+1);
        scanf("%d",&sonhap);
        
        
        if (sonhap > max) {
            min = mid;
            mid = max;
            max = sonhap;
        } else if (sonhap > mid) {
            min = mid;
            mid = sonhap;
        } else {
            min = sonhap;
        }
        
        
    }
    printf("%d %d %d.\n",min, mid, max);
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo17();
    return 0;
}
