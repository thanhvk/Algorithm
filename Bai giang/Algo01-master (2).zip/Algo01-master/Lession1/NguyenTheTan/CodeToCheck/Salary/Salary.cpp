//
//  main.cpp
//  Salary
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate Salary
void exNo15() {
    int sogio=0, tiengio=0,giotroi=0;
    int luong=0;
    
    freopen("dataex15.in", "r", stdin);
    scanf("%d",&sogio);
    scanf("%d",&tiengio);
    
    if (sogio > 40) {
        giotroi = sogio - 40;
        sogio = 40;
    }
    
    luong = sogio * tiengio + giotroi * tiengio * 2;
    
    printf("Thu nhap = %d * %d + %d * %d * 2 = %d\n",sogio,tiengio,giotroi,tiengio,luong);
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo15();
    return 0;
}
