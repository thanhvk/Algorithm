//
//  main.cpp
//  SumOddNums
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Sum the odd number from 1 to n
void exNo26() {
    int n=0, tongle=0;
    
    std::cout << "Tinh tong cac so le tu 0 den n\n";
    std::cout << "Nhap so n=";
    scanf("%d",&n);
    
    tongle = 0;
    for (int i=0;i<=n;i++){
        if (i % 2 > 0) {
            tongle = tongle + i;
        }
    }
    
    printf("Tong cac so le tu 0 den % d la:%d\n",n,tongle);
    
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo26();
    return 0;
}
