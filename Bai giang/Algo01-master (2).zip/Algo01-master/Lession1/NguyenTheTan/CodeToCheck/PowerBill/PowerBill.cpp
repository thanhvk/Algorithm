//
//  main.cpp
//  PowerBill
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate the electric power bill
void exNo19() {
    int thuebao = 1000;
    int gia50kwh = 230;
    int gia100kwh = 480;
    int gia150kwh = 700;
    int up50kwh = 900;
    
    int sodien=0;
    int tiendien=0;
    
    freopen("dataex19.in", "r", stdin);
    scanf("%d",&sodien);
    
    tiendien = tiendien + thuebao;
    
    if (sodien > 50) { //Dinh muc
        tiendien = tiendien + 50*gia50kwh;
        sodien = sodien - 50;
    }
    
    if (sodien > 50) { //50Kwh tiep theo
        tiendien = tiendien + 50*gia100kwh;
        sodien = sodien - 50;
    }
    
    if (sodien > 50) { //50kwh tiep theo
        tiendien = tiendien + 50*gia150kwh;
        sodien = sodien - 50;
    }
    
    if (sodien > 50) { //phan con lai
        tiendien = tiendien + 50*up50kwh;
        sodien = sodien - 50;
    }
    
    printf("Total = %d\n",tiendien);
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo19();
    return 0;
}
