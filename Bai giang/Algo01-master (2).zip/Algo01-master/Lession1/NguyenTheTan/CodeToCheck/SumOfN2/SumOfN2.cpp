//
//  main.cpp
//  SumOfN2
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate Sum of n integers
void exNo27() {
    int n=0, tong=0, sonhap=0;
    
    printf("Nhap n = ");
    scanf("%d",&n);
    
    for (int i=0; i<n; i++) {
        printf("So thu %d:",i+1);
        scanf("%d",&sonhap);
        
        tong = tong + sonhap;
    }
    printf("Tong %d so vua nhap vao la: %d",n,tong);
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo27();
    return 0;
}
