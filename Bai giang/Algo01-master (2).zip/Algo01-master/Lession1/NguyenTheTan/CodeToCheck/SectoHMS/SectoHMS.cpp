//
//  main.cpp
//  SectoHMS
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Change secs to h:m:s
void exNo9() {
    
    printf("Bai 9, doi so giay sang gio phut giay\n");
    int sogiay = 0;
    int gio = 0;
    int phut = 0;
    int giay = 0;
    std::cout << "Nhap vao so giay:";
    scanf("%d",&sogiay);
    
    if (sogiay >= 0 && sogiay <= 86399) {
        gio = sogiay / 3600;
        phut = (sogiay % 3600) / 60 ;
        giay = (sogiay % 3600) % 60;
        
    }
    printf("gio:phut:giay = %d:%d:%d",gio,phut,giay);
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo9();
    return 0;
}
