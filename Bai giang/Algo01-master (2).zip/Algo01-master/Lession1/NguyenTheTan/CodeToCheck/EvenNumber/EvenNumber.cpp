//
//  main.cpp
//  EvenNumber
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Print out even number
void exNo25() {
    int so1=0,so2=0;
    
    std::cout << "In cac so chan giua 2 so nguyen\n";
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);
    
    printf("Cac so chan nam giua so % d va so %d la:\n",so1,so2);
    for (int i=so1;i<so2;i++){
        if (i % 2 == 0) {
            printf("%d  ",i);
        }
    }
    printf("\n");
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo25();
    return 0;
}
