//
//  main.cpp
//  ReadFromFile1
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

//implement exercise 3
void exNo3() {
    freopen("dataex3.in", "r", stdin);
    int x=0;
    scanf("%d",&x);
    printf("So 1 o file la: %d\n",x);
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo3();
    return 0;
}
