//
//  main.cpp
//  SquareCube
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate the square and cube of Integer
void exNo8() {
    std::cout << "-----------Bai 8------------\n";
    std::cout << "Tinh binh phuong va lap phuong cua 1 so nguyen\n";
    int songuyen;
    
    int binhphuong = 0;
    int lapphuong = 0;
    std::cout << "Nhap so nguyen:";
    scanf("%d", &songuyen);
    binhphuong = songuyen * songuyen;
    lapphuong = songuyen * songuyen * songuyen;
    
    printf("Binh phuong so %d la: %d\n", songuyen,binhphuong);
    printf("Lap phuong so %d la: %d\n",songuyen,lapphuong);
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo8();
    return 0;
}
