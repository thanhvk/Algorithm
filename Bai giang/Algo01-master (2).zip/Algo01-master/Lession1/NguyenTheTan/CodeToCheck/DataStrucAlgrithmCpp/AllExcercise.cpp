//
//  main.cpp
//  DataStrucAlgrithmCpp
//
//  Created by Tan Nguyen on 3/13/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;


//Check a year is leap year or not
bool isLeapYear(int year) {
    if (year % 4 == 0) {
        return true;
    }

    if (year % 400 == 0) {
        return true;
    }
    
    if (year % 100 == 0) {
        return false;
    }
    
    return false;
}

//Check a number is prime number or not
bool isPrimeNumber(int n) {
    
    for (int i=2; i<n; i++) {
        if (n % i == 0) {
            return false;
            break;
        }
    }
    
    return true;
}

//Print out n chars
void doPrint(int num, char kitu) {
    for (int i=0; i < num; i++) {
        printf("%c",kitu);
    }
}

//implement exercise 2
void exNo2() {

    std::cout << "-----------Bai 2------------\n";
    std::cout << "Hello C++ World!\n";
    std::cout << "Cong hoa xa hoi chu nghia Viet Nam\n";
    std::cout << "   Doc lap * Tu do * Hanh phuc\n";
    
}

//implement exercise 3
void exNo3() {
    freopen("dataex3.in", "r", stdin);
    int x=0;
    scanf("%d",&x);
    printf("So 1 o file la: %d\n",x);
}

//implement exercise 4
void exNo4() {
    freopen("dataex3.in", "r", stdin);
    int x=0, y=0;
    scanf("%d",&x);
    scanf("%d",&y);
    printf("So 1 o file la: %d\n",x);
    printf("So 2 o file la: %d\n",y);
}

//calculate sum of 2 number
void exNo5() {

    std::cout << "-----------Bai 5------------\n";
    std::cout << "Tinh tong 2 so nguyen\n";
    int so1;
    int so2;
    int tong2so = 0;
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);

    tong2so = so1 + so2;

    printf("Tong 2 so la: %d\n", tong2so);

}

//calculate area of circle
void exNo6() {

    std::cout << "-----------Bai 6------------\n";
    std::cout << "Tinh dien tich hinh tron\n";
    int r;
    float pi = 3.14;
    float S =0.0;

    std::cout << "Nhap ban kinh hinh tron:";
    scanf("%d",&r);

    S = pi*r*r;

    printf("Dien tich hinh tron ban kinh r = %d la:%f\n",r,S);

}

//calculate area and volume of sphere
void exNo7() {

    std::cout << "-----------Bai 7------------\n";
    std::cout << "Tinh dien tich va the tich hinh cau\n";
    int rcau;
    float pi = 3.14;
    float Scau = 0.0;
    float Vcau = 0.0;
    std::cout << "Nhap ban kinh hinh cau:";
    scanf("%d",&rcau);
    
    Scau = 4*pi*rcau*rcau;
    Vcau = (4*pi*rcau*rcau*rcau)/3;
    
    printf("Dien tich hinh cau co ban kinh r = %d la:%f\n",rcau,Scau);
    printf("The tich hinh cau co ban kinh r = %d la:%f\n",rcau,Vcau);
    

}

//calculate the square and cube of Integer
void exNo8() {
    std::cout << "-----------Bai 8------------\n";
    std::cout << "Tinh binh phuong va lap phuong cua 1 so nguyen\n";
    int songuyen;

    int binhphuong = 0;
    int lapphuong = 0;
    std::cout << "Nhap so nguyen:";
    scanf("%d", &songuyen);
    binhphuong = songuyen * songuyen;
    lapphuong = songuyen * songuyen * songuyen;

    printf("Binh phuong so %d la: %d\n", songuyen,binhphuong);
    printf("Lap phuong so %d la: %d\n",songuyen,lapphuong);
    
}

//Change secs to h:m:s
void exNo9() {

    printf("Bai 9, doi so giay sang gio phut giay\n");
    int sogiay = 0;
    int gio = 0;
    int phut = 0;
    int giay = 0;
    std::cout << "Nhap vao so giay:";
    scanf("%d",&sogiay);

    if (sogiay >= 0 && sogiay <= 86399) {
        gio = sogiay / 3600;
        phut = (sogiay % 3600) / 60 ;
        giay = (sogiay % 3600) % 60;

    }
    printf("gio:phut:giay = %d:%d:%d",gio,phut,giay);

}

//Find max number
void exNo10() {

    int so1=0, so2=0;
    
    std::cout << "-----------Bai 10------------\n";
    std::cout << "Tim max 2 so nguyen\n";

    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);

    if (so1<so2) {
        printf("So lon nhat = %d\n",so2);
    } else {
        if (so1 == so2) {
            printf("Hai so bang nhau = %d\n",so2);
        }
        else {
            printf("So lon nhat = %d\n",so1);
        }
    }

}

//check numbers
void exNo11() {

    int so1=0,so2=0;
    
    std::cout << "-----------Bai 11------------\n";
    std::cout << "Phan biet 2 so nguyen\n";
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);

    if (so1 == so2) {
        printf("a = b = %d\n",so2);
    } else {
        printf("a = %d khac b = %d\n",so1,so2);
    }
    

}

//compare 2 numbers
void exNo12() {
    
    int so1=0,so2=0;
    
    std::cout << "-----------Bai 12------------\n";
    std::cout << "So sanh 2 so nguyen\n";
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);

    if (so1<so2) {
        printf("a = %d < b = %d\n",so1,so2);
    } else {
        if (so1 == so2) {
            printf("a = b = %d\n",so2);
        }
        else {
            printf("a = %d > b = %d\n",so1,so2);
        }
    }
    
   
}

//Ranking
void exNo13() {
    
    float diem = 0.0;
    
    std::cout << "-----------Bai 13------------\n";
    std::cout << "Xep hang hoc sinh\n";
    std::cout << "Nhap diem:";
    scanf("%f", &diem);
    
    if (diem < 5.0) {
        printf("Xep hang: Yeu\n");
    } else if (diem < 6.0) {
        printf("Xep hang: TB\n");
    } else if(diem < 7.0) {
        printf("Xep hang: TBK\n");
    } else if (diem < 8.0) {
        printf("Xep hang: Kha\n");
    } else if (diem < 9.0) {
        printf("Xep hang: Gioi\n");
    } else if (diem < 10.0) {
        printf("Xep hang: Xuat sac\n");
    } else {
        printf("Xep hang: Eo phai nguoi\n");
    }

}

//find max number
void exNo14(int n) {
    int sonhap=0,max=0;
    
    std::cout << "-----------Bai 14------------\n";
    for (int i=0;i<n;i++) {
        printf("Nhap so thu %d:",i+1);
        scanf("%d",&sonhap);
        if (sonhap > max) {
            max = sonhap;
        }
    }
    printf("%d la so lon nhat.\n",max);
}

//calculate Salary
void exNo15() {
    int sogio=0, tiengio=0,giotroi=0;
    int luong=0;
    
    freopen("dataex15.in", "r", stdin);
    scanf("%d",&sogio);
    scanf("%d",&tiengio);
    
    if (sogio > 40) {
        giotroi = sogio - 40;
        sogio = 40;
    }
    
    luong = sogio * tiengio + giotroi * tiengio * 2;
    
    printf("Thu nhap = %d * %d + %d * %d * 2 = %d\n",sogio,tiengio,giotroi,tiengio,luong);
}

//calculate perimeter of triangle
bool isTriangle(float a, float b, float c) {
    if ((a + b > c) && (a + c > b) && (b + c > a) ) {
        return true;
    }
    return false;
}

void exNo16() {
    float a=0.0,b=0.0,c=0.0,chuvi=0.0;
    
    printf("a = ");
    scanf("%f",&a);
    
    printf("b = ");
    scanf("%f",&b);
    
    printf("c = ");
    scanf("%f",&c);
    
    if (isTriangle(a, b, c)) {
        chuvi = a + b +c;
        printf("Chu vi = %f\n", chuvi);
    } else {
        printf("Khong phai tam giac!\n");
    }
}

//low to high
void exNo17() {
    int min=0,mid=0,max=0,sonhap=0;
    
    std::cout << "-----------Bai 17------------\n";
    for (int i=0;i<3;i++) {
        printf("Nhap so thu %d:",i+1);
        scanf("%d",&sonhap);
        

        if (sonhap > max) {
            min = mid;
            mid = max;
            max = sonhap;
        } else if (sonhap > mid) {
            min = mid;
            mid = sonhap;
        } else {
            min = sonhap;
        }
        
        
    }
    printf("%d %d %d.\n",min, mid, max);
}

//check number
void exNo18() {
    
    int n=0;
    
    freopen("dataex18.in", "r", stdin);
    scanf("%d",&n);
    
    if (n < 0) {
        printf("%d la so am\n",n);
    } else {
        if (n % 2 == 0) {
            printf("%d la so chan\n", n);
        } else {
            printf("%d la so le\n",n);
        }
    }
}

//calculate the electric power bill
void exNo19() {
    int thuebao = 1000;
    int gia50kwh = 230;
    int gia100kwh = 480;
    int gia150kwh = 700;
    int up50kwh = 900;
    
    int sodien=0;
    int tiendien=0;
    
    freopen("dataex19.in", "r", stdin);
    scanf("%d",&sodien);
    
    tiendien = tiendien + thuebao;
    
    if (sodien > 50) { //Dinh muc
        tiendien = tiendien + 50*gia50kwh;
        sodien = sodien - 50;
    }
    
    if (sodien > 50) { //50Kwh tiep theo
        tiendien = tiendien + 50*gia100kwh;
        sodien = sodien - 50;
    }

    if (sodien > 50) { //50kwh tiep theo
        tiendien = tiendien + 50*gia150kwh;
        sodien = sodien - 50;
    }

    if (sodien > 50) { //phan con lai
        tiendien = tiendien + 50*up50kwh;
        sodien = sodien - 50;
    }

    printf("Total = %d\n",tiendien);
    
}

//solving the equation 1
void exNo20() {
    int a = 0, b = 0;
    
    freopen("dataex20.in", "r", stdin);
    scanf("%d",&a);
    scanf("%d",&b);
    
    printf("Giai phuong trinh: %dx  %d = 0\n",a,b);
    if (a==0) {
        if (b==0) {
            printf("Phuong trinh vo so nghiem\n");
        } else {
            printf("Phuong trinh vo nghiem\n");
        }
    } else {
        printf("Phuong trinh co 1 nghiem x = %d/%d\n",-b,a);
    }
    
}

//solving the equation 2
void exNo21() {
    int a=0, b=0, c=0;
    int delta;

    freopen("dataex21.in", "r", stdin);
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    
    printf("Giai phuong trinh: %dx2 %dx %d = 0\n",a,b,c);
    
    if (a==0 && b==0 && c==0) {
        printf("Phuong trinh co vo so nghiem\n");
    } else {
        delta = b*b - 4*a*c;
        
        if (delta < 0) {
            printf("Phuong trinh vo nghiem\n");
        } else if (delta == 0) {
            printf("Phuong trinh co nghiem kep x1 = x2 = %d/2*%d\n",-b,a);
        } else {
            printf("Phuong trinh co 2 nghiem phan biet x1 = %d/2*%d. x2 = %d/4*%d",-b,a,-delta,a);
        }
    }

}

//using for loop
void exNo22() {
    int n=0;
    std::cout << "Vi du su dung vong lap FOR\n";
    std::cout << "Nhap so n=";
    scanf("%d",&n);

    for (int i=0;i<n;i++) {
        printf("Dung vong lap FOR lap lan thu %d\n",i);
    }

}

//Print out integer
void exNo23() {
    int so1=0,so2=0;
    
    std::cout << "In cac so giua 2 so nguyen\n";
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);

    printf("Cac so nam giua so % d va so %d la:\n",so1,so2);
    for (int i=so1+1;i<so2;i++){
        printf("%d  ",i);
    }
    printf("\n");

}

//Calculate the Sum of n
void exNo24() {
    int n=0,tong=0;
    
    std::cout << "Tinh tong cac so tu 1 den n\n";
    std::cout << "Nhap so n=";
    scanf("%d",&n);

    for (int i=1;i<=n;i++) {
        tong += i;
    }
    printf("Tong cac so tu 1 den %d la %d\n",n,tong);

}

//Print out even number
void exNo25() {
    int so1=0,so2=0;
    
    std::cout << "In cac so chan giua 2 so nguyen\n";
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);

    printf("Cac so chan nam giua so % d va so %d la:\n",so1,so2);
    for (int i=so1;i<so2;i++){
        if (i % 2 == 0) {
        printf("%d  ",i);
        }
    }
    printf("\n");
   
}

//Sum the odd number from 1 to n
void exNo26() {
    int n=0, tongle=0;
    
    std::cout << "Tinh tong cac so le tu 0 den n\n";
    std::cout << "Nhap so n=";
    scanf("%d",&n);

    tongle = 0;
    for (int i=0;i<=n;i++){
        if (i % 2 > 0) {
            tongle = tongle + i;
        }
    }

    printf("Tong cac so le tu 0 den % d la:%d\n",n,tongle);
    

}

//calculate Sum of n integers
void exNo27() {
    int n=0, tong=0, sonhap=0;
    
    printf("Nhap n = ");
    scanf("%d",&n);
    
    for (int i=0; i<n; i++) {
        printf("So thu %d:",i+1);
        scanf("%d",&sonhap);
        
        tong = tong + sonhap;
    }
    printf("Tong %d so vua nhap vao la: %d",n,tong);
}

//Test while loop
void exNo28() {
    int n=0,sonhap=0;

    freopen("dataex28.in", "r", stdin);
    
    while (n==0) {
        scanf("%d",&sonhap);
        
        if (sonhap % 10 == 0) {
            n=1;
        } else {
            printf("%d ",sonhap);
        }
    }
}

//calculate Sum of odd and sum of even
void exNo29() {
    std::cout << "Tinh tong chan va tong le tu 1 den n\n";
    int n;
    int tongchan = 0;
    int tongle = 0;
    std::cout << "Nhap so n=";
    scanf("%d",&n);

    for (int i=1;i<=n;i++){
        if (i % 2 == 0) {
            tongchan = tongchan + i;
        } else {
            tongle = tongle + i;
        }
    }

    printf("Tong cac so chan tu 1 den %d la:%d\n",n,tongchan);
    printf("Tong cac so le tu 1 den % d la:%d\n",n,tongle);

}

//Change secs to h:m:s
void exNo30() {
        printf("Bai giao o lop\n");
        int sogiay = 0;
        int gio = 0;
        int phut = 0;
        int giay = 0;
        int giaytroi=0;
    
        printf("Nhap gio:");
        scanf("%d",&gio);
        printf("Nhap phut:");
        scanf("%d",&phut);
    
        printf("Nhap giay:");
        scanf("%d",&giay);
    
        if (gio > 23) { gio = 0;}
        if (phut > 59) { phut = 0;}
        if (giay > 60) { giay = 60;}
    
        printf("Bay gio la: %d:%d:%d\n", gio, phut, giay);
    
        printf("Nhap giay troi:");
        scanf("%d",&giaytroi);
    
        sogiay = gio * 3600 + phut * 60 + giay + giaytroi;
        gio = sogiay / 3600;
        phut = (sogiay % 3600) / 60 ;
        giay = (sogiay % 3600) % 60;
        
        printf("\n");
        printf("Ket qua la: gio:phut:giay = %dh:%dm:%ds\n",gio,phut,giay);

}

//check leap Year
void exNo31() {
    int nam=0;
    
    printf("Nhap nam: ");
    scanf("%d",&nam);
    
    if (isLeapYear(nam)) {
        printf("Nam nhuan\n");
    }
    else {
        printf("Khong nhuan\n");
    }
    
}

//Find the prime number
void exNo32() {
    int n=0;
    printf("In ra so nguyen to tu 1-n\n");
    printf("Nhap so n:");
    scanf("%d",&n);

    for (int i=1; i<=n; i++) {
        if (isPrimeNumber(i)) {
            printf("%d  ",i);
        }
    }
    
}

//Draw a rectangle
void exNo33() {
    int dai = 0;
    int rong = 0;

    printf("In ra hinh chu nhat\n");
    printf("Nhap chieu dai:");
    scanf("%d",&dai);
    printf("Nhap chieu rong:");
    scanf("%d",&rong);


    for (int y=0; y<rong;y++) {
        for (int x=0; x<dai; x++) {
            if (y==0 || y==rong-1) {
                printf("*");
            }
            else {
                if (x==0 || x==dai-1) {
                    printf("*");
                } else {
                    printf(" ");
                }
            }
        }
        printf("\n");
    }

//Another way
    printf("Another way:\n");
    doPrint(dai, '*');
    printf("\n");

    for (int i=0; i < rong-2; i++) {
        doPrint(1, '*');
        doPrint(dai-2, ' ');
        doPrint(1, '*');
        printf("\n");
    }

    doPrint(dai, '*');
    printf("\n");

}

//draw a triangle
void exNo34() {
    int high=0;
    int maxwidth = 0;
    
    freopen("dataex34.in", "r", stdin);
    scanf("%d",&high);
    
    maxwidth = 2*(high-1)+1; //muc high tinh tu 0.
    
    for (int i=0; i<high; i++) {
        doPrint(maxwidth-(i+high),' ');
        doPrint(2*i+1, '*');
        printf("\n");
    }
}

//draw a rectangle with width, height get from file
//Another way
void exNo35() {
    
    int dai = 0, rong = 0;
    
    freopen("dataex35.in", "r", stdin);
    scanf("%d",&dai);
    scanf("%d",&rong);
    
    if (dai > 2 && rong>2) {
        doPrint(dai, '*');
        printf("\n");
        
        for (int i=0; i < rong-2; i++) {
            doPrint(1, '*');
            doPrint(dai-2, ' ');
            doPrint(1, '*');
            printf("\n");
        }
        
        doPrint(dai, '*');
        printf("\n");

    }
    else {
        printf("Chieu dai va chieu rong phai lon hon 2\n");
    }
    
}

//check prime number for N numbers
void exNo36() {
    int n=0, sonhap=0;
    
    printf("Nhap n:");
    scanf("%d",&n);
    if (n>0 && n<100) {
        for (int i=0; i<n; i++) {
            printf("Nhap so can kiem tra:");
            scanf("%d",&sonhap);
            
            if (isPrimeNumber(sonhap)) {
                printf("%d la so nguyen to\n",sonhap);
            } else {
                printf("%d khong phai la so nguyen to\n",sonhap);
            }
            
        }
    } else {
        printf("So %d khong hop le\n",n);
    }
    
}

//draw an emty triangle
void exNo37() {
    int high = 0;
    int maxwidth=0;
    
    freopen("dataex37.in", "r", stdin);
    scanf("%d",&high);
    
    maxwidth = 2*(high-1)+1; //high start from 0.

    //draw top of triangle

    doPrint(maxwidth-high,' ');
    doPrint(1, '*');
    printf("\n");
    
    //draw body of triangle
    for (int i=2; i<high; i++) {
        doPrint(maxwidth-(i+high-1),' ');
        doPrint(1, '*');
        doPrint(2*i-3, ' ');
        doPrint(1, '*');
        printf("\n");
    }
    
    //draw bottom of triangle
    doPrint(maxwidth, '*');
    printf("\n");
}

//find and count min number
void exNo38() {
    int min=100;
    int count = 0;
    int sonhap = 100;
    
    freopen("dataex38.in", "r", stdin);
    scanf("%d",&sonhap);
    
    while (sonhap<100) {
        if (sonhap==min) {
            count++;
        }

        if (sonhap<min) {
            min=sonhap;
            count=1;
        }
        scanf("%d",&sonhap);

    }
    
    printf("Min = %d. Xuat hien %d lan\n",min,count);
}

//Calcualte sum of digit in number
void exNo39() {
    int sum=0;
    int sonhap=0;
    
    printf("Nhap so < 10000:");
    scanf("%d",&sonhap);
    
    if (sonhap < 10000) {
        
        if (sonhap > 999) {
            sum = sum + sonhap/1000;
            sonhap = sonhap % 1000;
        }
        if (sonhap>99) {
            sum = sum + sonhap/100;
            sonhap = sonhap % 100;
        }
        if (sonhap>9) {
            sum = sum + sonhap/10;
            sonhap = sonhap % 10;
        }
        
        sum = sum + sonhap;
        
        printf("Tong cac chu so la: %d",sum);
    } else {
        printf("So nhap sai!\n");
    }
}

//draw character 'N'
void exNo40() {
    int rong=0,cao=0;
    
    //rong = 3*cao required
    freopen("dataex40.in", "r", stdin);
    scanf("%d",&rong);
    scanf("%d",&cao);
    
    if (cao==rong/3) {
        //draw top
        doPrint(1, '*');
        doPrint(rong-cao*2, ' ');
        doPrint(1, '*');
        printf("\n");
        
        //draw body
        for (int i=0; i<cao-2; i++) {
            doPrint(1, '*');
            doPrint(i+1, ' ');
            doPrint(1, '*');
            doPrint(rong-cao*2-(i+2), ' ');
            doPrint(1,'*');
            printf("\n");

        }
        
        //draw bottom
        doPrint(1, '*');
        doPrint(rong-cao*2, ' ');
        doPrint(1, '*');
        printf("\n");
    } else {
        printf("Yeu cau chieu rong = 3 lan chieu cao\n");
    }
}

//draw a golden fish
void exNo41() {
    int high = 0;
    int rong =0;
    
    freopen("dataex41.in", "r", stdin);
    scanf("%d",&high);
    
    rong = high+high/2;
    
    if (high>1 && high%2>0) {
        //draw top
        for (int i=1; i<=high/2; i++) {
            doPrint(i, '*');
            doPrint(high-2*i, ' ');
            doPrint(2*i-1, '*');
            printf("\n");
            
        }
        
        //draw backbone
        doPrint(rong, '*');
        printf("\n");
        
        //draw bottom
        for (int i=high/2; i>=1; i--) {
            doPrint(i, '*');
            doPrint(high-2*i, ' ');
            doPrint(2*i-1, '*');
            printf("\n");
        }
        
        
    } else {
        printf("chieu cao khong hop le.\n");
    }
    
}
//------------------------------------------------------------------------
int main(int argc, const char * argv[]) {
    // run your code here...
    
    exNo41();

    printf("\n");
    printf("KET THUC BAI TAP LAM QUEN VOI NGON NGU C++\n");
    return 0;
}
