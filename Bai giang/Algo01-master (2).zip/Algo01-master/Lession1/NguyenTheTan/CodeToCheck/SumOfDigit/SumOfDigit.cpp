//
//  main.cpp
//  SumOfDigit
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Calcualte sum of digit in number
void exNo39() {
    int sum=0;
    int sonhap=0;
    
    printf("Nhap so < 10000:");
    scanf("%d",&sonhap);
    
    if (sonhap < 10000) {
        
        if (sonhap > 999) {
            sum = sum + sonhap/1000;
            sonhap = sonhap % 1000;
        }
        if (sonhap>99) {
            sum = sum + sonhap/100;
            sonhap = sonhap % 100;
        }
        if (sonhap>9) {
            sum = sum + sonhap/10;
            sonhap = sonhap % 10;
        }
        
        sum = sum + sonhap;
        
        printf("Tong cac chu so la: %d",sum);
    } else {
        printf("So nhap sai!\n");
    }
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo39();
    return 0;
}
