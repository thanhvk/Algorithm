//
//  main.cpp
//  Rectangle
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Print out n chars
void doPrint(int num, char kitu) {
    for (int i=0; i < num; i++) {
        printf("%c",kitu);
    }
}

//Draw a rectangle
void exNo33() {
    int dai = 0;
    int rong = 0;
    
    printf("In ra hinh chu nhat\n");
    printf("Nhap chieu dai:");
    scanf("%d",&dai);
    printf("Nhap chieu rong:");
    scanf("%d",&rong);
    
    
    for (int y=0; y<rong;y++) {
        for (int x=0; x<dai; x++) {
            if (y==0 || y==rong-1) {
                printf("*");
            }
            else {
                if (x==0 || x==dai-1) {
                    printf("*");
                } else {
                    printf(" ");
                }
            }
        }
        printf("\n");
    }
    
    //Another way
    printf("Another way:\n");
    doPrint(dai, '*');
    printf("\n");
    
    for (int i=0; i < rong-2; i++) {
        doPrint(1, '*');
        doPrint(dai-2, ' ');
        doPrint(1, '*');
        printf("\n");
    }
    
    doPrint(dai, '*');
    printf("\n");
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo33();
    return 0;
}
