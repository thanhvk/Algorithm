//
//  main.cpp
//  PupilRanking
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Ranking
void exNo13() {
    
    float diem = 0.0;
    
    std::cout << "-----------Bai 13------------\n";
    std::cout << "Xep hang hoc sinh\n";
    std::cout << "Nhap diem:";
    scanf("%f", &diem);
    
    if (diem < 5.0) {
        printf("Xep hang: Yeu\n");
    } else if (diem < 6.0) {
        printf("Xep hang: TB\n");
    } else if(diem < 7.0) {
        printf("Xep hang: TBK\n");
    } else if (diem < 8.0) {
        printf("Xep hang: Kha\n");
    } else if (diem < 9.0) {
        printf("Xep hang: Gioi\n");
    } else if (diem < 10.0) {
        printf("Xep hang: Xuat sac\n");
    } else {
        printf("Xep hang: Eo phai nguoi\n");
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo13();
    return 0;
}
