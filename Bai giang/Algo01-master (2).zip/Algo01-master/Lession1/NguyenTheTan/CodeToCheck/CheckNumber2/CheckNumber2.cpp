//
//  main.cpp
//  CheckNumber2
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//check number
void exNo18() {
    
    int n=0;
    
    freopen("dataex18.in", "r", stdin);
    scanf("%d",&n);
    
    if (n < 0) {
        printf("%d la so am\n",n);
    } else {
        if (n % 2 == 0) {
            printf("%d la so chan\n", n);
        } else {
            printf("%d la so le\n",n);
        }
    }
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo18();
    return 0;
}
