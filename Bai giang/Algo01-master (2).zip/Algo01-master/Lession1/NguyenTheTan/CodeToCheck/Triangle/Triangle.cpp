//
//  main.cpp
//  Triangle
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Print out n chars
void doPrint(int num, char kitu) {
    for (int i=0; i < num; i++) {
        printf("%c",kitu);
    }
}

//draw a triangle
void exNo34() {
    int high=0;
    int maxwidth = 0;
    
    freopen("dataex34.in", "r", stdin);
    scanf("%d",&high);
    
    maxwidth = 2*(high-1)+1; //muc high tinh tu 0.
    
    for (int i=0; i<high; i++) {
        doPrint(maxwidth-(i+high),' ');
        doPrint(2*i+1, '*');
        printf("\n");
    }
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo34();
    return 0;
}
