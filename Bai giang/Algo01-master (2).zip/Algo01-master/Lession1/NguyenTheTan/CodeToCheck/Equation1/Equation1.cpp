//
//  main.cpp
//  Equation1
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//solving the equation 1
void exNo20() {
    int a = 0, b = 0;
    
    freopen("dataex20.in", "r", stdin);
    scanf("%d",&a);
    scanf("%d",&b);
    
    printf("Giai phuong trinh: %dx  %d = 0\n",a,b);
    if (a==0) {
        if (b==0) {
            printf("Phuong trinh vo so nghiem\n");
        } else {
            printf("Phuong trinh vo nghiem\n");
        }
    } else {
        printf("Phuong trinh co 1 nghiem x = %d/%d\n",-b,a);
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo20();
    return 0;
}
