//
//  main.cpp
//  Equation2
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//solving the equation 2
void exNo21() {
    int a=0, b=0, c=0;
    int delta;
    
    freopen("dataex21.in", "r", stdin);
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    
    printf("Giai phuong trinh: %dx2 %dx %d = 0\n",a,b,c);
    
    if (a==0 && b==0 && c==0) {
        printf("Phuong trinh co vo so nghiem\n");
    } else {
        delta = b*b - 4*a*c;
        
        if (delta < 0) {
            printf("Phuong trinh vo nghiem\n");
        } else if (delta == 0) {
            printf("Phuong trinh co nghiem kep x1 = x2 = %d/2*%d\n",-b,a);
        } else {
            printf("Phuong trinh co 2 nghiem phan biet x1 = %d/2*%d. x2 = %d/4*%d",-b,a,-delta,a);
        }
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo21();
    return 0;
}
