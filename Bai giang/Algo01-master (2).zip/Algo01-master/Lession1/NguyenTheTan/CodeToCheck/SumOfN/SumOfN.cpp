//
//  main.cpp
//  SumOfN
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Calculate the Sum of n
void exNo24() {
    int n=0,tong=0;
    
    std::cout << "Tinh tong cac so tu 1 den n\n";
    std::cout << "Nhap so n=";
    scanf("%d",&n);
    
    for (int i=1;i<=n;i++) {
        tong += i;
    }
    printf("Tong cac so tu 1 den %d la %d\n",n,tong);
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo24();
    return 0;
}
