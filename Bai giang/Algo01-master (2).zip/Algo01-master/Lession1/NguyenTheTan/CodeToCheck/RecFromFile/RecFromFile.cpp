//
//  main.cpp
//  RecFromFile
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Print out n chars
void doPrint(int num, char kitu) {
    for (int i=0; i < num; i++) {
        printf("%c",kitu);
    }
}

//draw a rectangle with width, height get from file
//Another way
void exNo35() {
    
    int dai = 0, rong = 0;
    
    freopen("dataex35.in", "r", stdin);
    scanf("%d",&dai);
    scanf("%d",&rong);
    
    if (dai > 2 && rong>2) {
        doPrint(dai, '*');
        printf("\n");
        
        for (int i=0; i < rong-2; i++) {
            doPrint(1, '*');
            doPrint(dai-2, ' ');
            doPrint(1, '*');
            printf("\n");
        }
        
        doPrint(dai, '*');
        printf("\n");
        
    }
    else {
        printf("Chieu dai va chieu rong phai lon hon 2\n");
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo35();
    return 0;
}
