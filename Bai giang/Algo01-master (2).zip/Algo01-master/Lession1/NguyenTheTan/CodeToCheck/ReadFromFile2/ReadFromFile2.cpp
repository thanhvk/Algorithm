//
//  main.cpp
//  ReadFromFile2
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>


//implement exercise 4
void exNo4() {
    freopen("dataex3.in", "r", stdin);
    int x=0, y=0;
    scanf("%d",&x);
    scanf("%d",&y);
    printf("So 1 o file la: %d\n",x);
    printf("So 2 o file la: %d\n",y);
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo4();
    return 0;
}
