//
//  main.cpp
//  DrawCharN
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Print out n chars
void doPrint(int num, char kitu) {
    for (int i=0; i < num; i++) {
        printf("%c",kitu);
    }
}


//draw character 'N'
void exNo40() {
    int rong=0,cao=0;
    
    //rong = 3*cao required
    freopen("dataex40.in", "r", stdin);
    scanf("%d",&rong);
    scanf("%d",&cao);
    
    if (cao==rong/3) {
        //draw top
        doPrint(1, '*');
        doPrint(rong-cao*2, ' ');
        doPrint(1, '*');
        printf("\n");
        
        //draw body
        for (int i=0; i<cao-2; i++) {
            doPrint(1, '*');
            doPrint(i+1, ' ');
            doPrint(1, '*');
            doPrint(rong-cao*2-(i+2), ' ');
            doPrint(1,'*');
            printf("\n");
            
        }
        
        //draw bottom
        doPrint(1, '*');
        doPrint(rong-cao*2, ' ');
        doPrint(1, '*');
        printf("\n");
    } else {
        printf("Yeu cau chieu rong = 3 lan chieu cao\n");
    }
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo40();
    return 0;
}
