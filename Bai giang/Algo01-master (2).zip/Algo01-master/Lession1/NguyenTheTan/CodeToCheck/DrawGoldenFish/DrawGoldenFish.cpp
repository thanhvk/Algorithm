//
//  main.cpp
//  DrawGoldenFish
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Print out n chars
void doPrint(int num, char kitu) {
    for (int i=0; i < num; i++) {
        printf("%c",kitu);
    }
}

//draw a golden fish
void exNo41() {
    int high = 0;
    int rong =0;
    
    freopen("dataex41.in", "r", stdin);
    scanf("%d",&high);
    
    rong = high+high/2;
    
    if (high>1 && high%2>0) {
        //draw top
        for (int i=1; i<=high/2; i++) {
            doPrint(i, '*');
            doPrint(high-2*i, ' ');
            doPrint(2*i-1, '*');
            printf("\n");
            
        }
        
        //draw backbone
        doPrint(rong, '*');
        printf("\n");
        
        //draw bottom
        for (int i=high/2; i>=1; i--) {
            doPrint(i, '*');
            doPrint(high-2*i, ' ');
            doPrint(2*i-1, '*');
            printf("\n");
        }
        
        
    } else {
        printf("chieu cao khong hop le.\n");
    }
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo41();
    return 0;
}
