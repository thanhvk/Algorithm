//
//  main.cpp
//  CheckNumber
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//check numbers
void exNo11() {
    
    int so1=0,so2=0;
    
    std::cout << "-----------Bai 11------------\n";
    std::cout << "Phan biet 2 so nguyen\n";
    std::cout << "Nhap so nguyen thu nhat:";
    scanf("%d", &so1);
    std::cout << "Nhap so nguyen thu hai:";
    scanf("%d", &so2);
    
    if (so1 == so2) {
        printf("a = b = %d\n",so2);
    } else {
        printf("a = %d khac b = %d\n",so1,so2);
    }
    
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo11();
    return 0;
}
