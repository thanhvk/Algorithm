//
//  main.cpp
//  FindAndCountMin
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//find and count min number
void exNo38() {
    int min=100;
    int count = 0;
    int sonhap = 100;
    
    freopen("dataex38.in", "r", stdin);
    scanf("%d",&sonhap);
    
    while (sonhap<100) {
        if (sonhap==min) {
            count++;
        }
        
        if (sonhap<min) {
            min=sonhap;
            count=1;
        }
        scanf("%d",&sonhap);
        
    }
    
    printf("Min = %d. Xuat hien %d lan\n",min,count);
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo38();
    return 0;
}
