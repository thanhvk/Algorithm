//
//  main.cpp
//  SectoHMS2
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Change secs to h:m:s
void exNo30() {
    printf("Bai giao o lop\n");
    int sogiay = 0;
    int gio = 0;
    int phut = 0;
    int giay = 0;
    int giaytroi=0;
    
    printf("Nhap gio:");
    scanf("%d",&gio);
    printf("Nhap phut:");
    scanf("%d",&phut);
    
    printf("Nhap giay:");
    scanf("%d",&giay);
    
    if (gio > 23) { gio = 0;}
    if (phut > 59) { phut = 0;}
    if (giay > 60) { giay = 60;}
    
    printf("Bay gio la: %d:%d:%d\n", gio, phut, giay);
    
    printf("Nhap giay troi:");
    scanf("%d",&giaytroi);
    
    sogiay = gio * 3600 + phut * 60 + giay + giaytroi;
    gio = sogiay / 3600;
    phut = (sogiay % 3600) / 60 ;
    giay = (sogiay % 3600) % 60;
    
    printf("\n");
    printf("Ket qua la: gio:phut:giay = %dh:%dm:%ds\n",gio,phut,giay);
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo30();
    return 0;
}
