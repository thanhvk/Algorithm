//
//  main.cpp
//  Perimeter
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate perimeter of triangle
bool isTriangle(float a, float b, float c) {
    if ((a + b > c) && (a + c > b) && (b + c > a) ) {
        return true;
    }
    return false;
}

void exNo16() {
    float a=0.0,b=0.0,c=0.0,chuvi=0.0;
    
    printf("a = ");
    scanf("%f",&a);
    
    printf("b = ");
    scanf("%f",&b);
    
    printf("c = ");
    scanf("%f",&c);
    
    if (isTriangle(a, b, c)) {
        chuvi = a + b +c;
        printf("Chu vi = %f\n", chuvi);
    } else {
        printf("Khong phai tam giac!\n");
    }
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo16();
    return 0;
}
