//
//  main.cpp
//  CircleArea
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate area of circle
void exNo6() {
    
    std::cout << "-----------Bai 6------------\n";
    std::cout << "Tinh dien tich hinh tron\n";
    int r;
    float pi = 3.14;
    float S =0.0;
    
    std::cout << "Nhap ban kinh hinh tron:";
    scanf("%d",&r);
    
    S = pi*r*r;
    
    printf("Dien tich hinh tron ban kinh r = %d la:%f\n",r,S);
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo6();
    return 0;
}
