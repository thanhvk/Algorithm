//
//  main.cpp
//  LeapYear
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Check a year is leap year or not
bool isLeapYear(int year) {
    if (year % 4 == 0) {
        return true;
    }
    
    if (year % 400 == 0) {
        return true;
    }
    
    if (year % 100 == 0) {
        return false;
    }
    
    return false;
}

//check leap Year
void exNo31() {
    int nam=0;
    
    printf("Nhap nam: ");
    scanf("%d",&nam);
    
    if (isLeapYear(nam)) {
        printf("Nam nhuan\n");
    }
    else {
        printf("Khong nhuan\n");
    }
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo31();
    return 0;
}
