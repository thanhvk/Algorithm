//
//  main.cpp
//  WhileLoop
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Test while loop
void exNo28() {
    int n=0,sonhap=0;
    
    freopen("dataex28.in", "r", stdin);
    
    while (n==0) {
        scanf("%d",&sonhap);
        
        if (sonhap % 10 == 0) {
            n=1;
        } else {
            printf("%d ",sonhap);
        }
    }
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo28();
    return 0;
}
