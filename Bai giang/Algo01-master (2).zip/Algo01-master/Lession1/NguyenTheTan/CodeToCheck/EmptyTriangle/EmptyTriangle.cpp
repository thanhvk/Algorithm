//
//  main.cpp
//  EmptyTriangle
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//Print out n chars
void doPrint(int num, char kitu) {
    for (int i=0; i < num; i++) {
        printf("%c",kitu);
    }
}

//draw an emty triangle
void exNo37() {
    int high = 0;
    int maxwidth=0;
    
    freopen("dataex37.in", "r", stdin);
    scanf("%d",&high);
    
    maxwidth = 2*(high-1)+1; //high start from 0.
    
    //draw top of triangle
    
    doPrint(maxwidth-high,' ');
    doPrint(1, '*');
    printf("\n");
    
    //draw body of triangle
    for (int i=2; i<high; i++) {
        doPrint(maxwidth-(i+high-1),' ');
        doPrint(1, '*');
        doPrint(2*i-3, ' ');
        doPrint(1, '*');
        printf("\n");
    }
    
    //draw bottom of triangle
    doPrint(maxwidth, '*');
    printf("\n");
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo37();
    return 0;
}
