//
//  main.cpp
//  SumOddEven
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate Sum of odd and sum of even
void exNo29() {
    std::cout << "Tinh tong chan va tong le tu 1 den n\n";
    int n;
    int tongchan = 0;
    int tongle = 0;
    std::cout << "Nhap so n=";
    scanf("%d",&n);
    
    for (int i=1;i<=n;i++){
        if (i % 2 == 0) {
            tongchan = tongchan + i;
        } else {
            tongle = tongle + i;
        }
    }
    
    printf("Tong cac so chan tu 1 den %d la:%d\n",n,tongchan);
    printf("Tong cac so le tu 1 den % d la:%d\n",n,tongle);
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo29();
    return 0;
}
