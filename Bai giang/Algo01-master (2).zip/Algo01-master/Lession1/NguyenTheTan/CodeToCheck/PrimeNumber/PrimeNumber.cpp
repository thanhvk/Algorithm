//
//  main.cpp
//  PrimeNumber
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>


//Check a number is prime number or not
bool isPrimeNumber(int n) {
    
    for (int i=2; i<n; i++) {
        if (n % i == 0) {
            return false;
            break;
        }
    }
    
    return true;
}

//Find the prime number
void exNo32() {
    int n=0;
    printf("In ra so nguyen to tu 1-n\n");
    printf("Nhap so n:");
    scanf("%d",&n);
    
    for (int i=1; i<=n; i++) {
        if (isPrimeNumber(i)) {
            printf("%d  ",i);
        }
    }
    
}


int main(int argc, const char * argv[]) {
    // insert code here...
    exNo32();
    return 0;
}
