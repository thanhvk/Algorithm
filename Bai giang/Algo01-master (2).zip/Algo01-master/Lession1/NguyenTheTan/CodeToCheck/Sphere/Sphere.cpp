//
//  main.cpp
//  Sphere
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//calculate area and volume of sphere
void exNo7() {
    
    std::cout << "-----------Bai 7------------\n";
    std::cout << "Tinh dien tich va the tich hinh cau\n";
    int rcau;
    float pi = 3.14;
    float Scau = 0.0;
    float Vcau = 0.0;
    std::cout << "Nhap ban kinh hinh cau:";
    scanf("%d",&rcau);
    
    Scau = 4*pi*rcau*rcau;
    Vcau = (4*pi*rcau*rcau*rcau)/3;
    
    printf("Dien tich hinh cau co ban kinh r = %d la:%f\n",rcau,Scau);
    printf("The tich hinh cau co ban kinh r = %d la:%f\n",rcau,Vcau);
    
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo7();
    return 0;
}
