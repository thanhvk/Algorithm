//
//  main.cpp
//  MaxNumber2
//
//  Created by Tan Nguyen on 3/18/16.
//  Copyright © 2016 TMT Game Studio. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

//find max number
void exNo14(int n) {
    int sonhap=0,max=0;
    
    std::cout << "-----------Bai 14------------\n";
    for (int i=0;i<n;i++) {
        printf("Nhap so thu %d:",i+1);
        scanf("%d",&sonhap);
        if (sonhap > max) {
            max = sonhap;
        }
    }
    printf("%d la so lon nhat.\n",max);
}

int main(int argc, const char * argv[]) {
    // insert code here...
    exNo14(5);
    return 0;
}
