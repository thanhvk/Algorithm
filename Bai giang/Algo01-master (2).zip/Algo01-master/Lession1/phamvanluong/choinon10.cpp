#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;
int TongTien(int soDien);

int main()
{
	freopen("choinon10.inp","r",stdin);
	freopen("choinon10.out","w",stdout);
	
	int a;
	scanf("%d",&a);
	
	printf("Tong tien dien la: %d",TongTien(a));

	return 0;
}


int TongTien(int soDien){
	int tongTien,soDienVuot;
	soDienVuot= soDien - 50;
	if(soDienVuot <=0){
		tongTien = soDien * 230 + 1000;
	}
	else if(0<soDienVuot <=50){
		tongTien = 50*230 + soDienVuot*480 + 1000;
	}
	else if(50< soDienVuot < 100){
		tongTien = 50*230 + soDienVuot*700 + 1000;
	}
	else if(soDienVuot >=100){
		tongTien = 50*230 + soDienVuot*900 +1000;
	}
	
	return tongTien;
}

	

