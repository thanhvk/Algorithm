//
//  main.cpp
//  ForWhile_2
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int a, b;
    scanf("%d %d", &a, &b);
    for (int i = a; i<=b; i++) {
        printf("%d\n",i);
    }
    return 0;
}
