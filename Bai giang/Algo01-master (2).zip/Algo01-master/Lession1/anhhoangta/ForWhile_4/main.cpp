//
//  main.cpp
//  ForWhile_4
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int a, b;
    scanf("%d %d", &a, &b);
    if (a%2 == 0) {
        for (int i = a; i<=b; i+=2) {
            printf("%d\n",i);
        }

    }else
        for (int i = a+1; i<=b; i+=2) {
            printf("%d\n",i);
        }
    
    return 0;
}
