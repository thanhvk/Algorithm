//
//  main.cpp
//  IF_13
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    float x;
    printf("Input scores\n");
    scanf("%f", &x);
    if (x >= 9) {
        printf("Xuat sac");
    }else if (x >= 8) {
        printf("Gioi");
    }else if (x >= 7) {
        printf("Kha");
    }else if (x >=6) {
        printf("TBKha");
    }else if (x >=5) {
        printf("TBinh");
    }else
        printf("Yeu");
    
    return 0;
}
