//
//  main.cpp
//  ForWhile_5
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int n, S;
    scanf("%d", &n);
    S = 0;
    for (int i=0; i <= n; i++) {
        if (i%2 == 1) {
            S += i;
        }
    }
    printf("%d", S);
    return 0;
}
