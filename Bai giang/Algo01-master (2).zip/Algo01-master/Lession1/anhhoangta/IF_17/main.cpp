//
//  main.cpp
//  IF_17
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int sort(int x, int y, int z){
    if (x < y && x < z) {
        if (y < z) {
            printf("%d %d %d", x, y, z);
        }else
        printf("%d %d %d", x, z, y);
    }
    return 0;
}

int main(int argc, const char * argv[]) {
    int x, y, z;
    scanf("%d %d %d", &x, &y, &z);
    sort(x, y, z);
    sort(y, z, x);
    sort(z, x, y);
    
    return 0;
}
