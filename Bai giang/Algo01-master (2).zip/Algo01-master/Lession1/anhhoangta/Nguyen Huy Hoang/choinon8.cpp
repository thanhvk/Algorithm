//
//  main.cpp
//  IF_17
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int x, y, z;
    scanf("%d %d %d", &x, &y, &z);
    if (x <= y) {
        if (y <= z)
            printf("%d %d %d", x, y, z);
        else {
            if (z >= x)
                printf("%d %d %d", x, z, y);
            else
                printf("%d %d %d", z, x, y);
        }
    }else {
        if (y >= z)
            printf("%d %d %d", z, y, x);
        else {
            if (z >=x)
                printf("%d %d %d", y, x, z);
            else
                printf("%d %d %d", y, z, x);
        }
    }
    return 0;
}
