//
//  main.cpp
//  IF_15
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int x, y;
    scanf("%d %d", &x, &y);
    if (x <= 40) {
        printf("%d", x*y);
    }else
        printf("%d", 40*y + 2*(x-40)*y);
    return 0;
}
