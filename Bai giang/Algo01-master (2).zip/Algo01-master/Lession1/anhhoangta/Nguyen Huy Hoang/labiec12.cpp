//
//  main.cpp
//  ForWhile_10
//
//  Created by anhhoangta on 3/17/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <math.h>
#include <fstream>

bool CheckPrimeNumber(int n){
    if (n <2)
        return false;
    else if (n == 2)
        return true;
    else{
        for (int i=2; i <= n; i++) {
            if (n%i == 0)
                return false;
        }
        return true;
    }
    return false;
}


int main(int argc, const char * argv[]) {
    int n, a;
    scanf("%d", &n);
    
    for (int i=0; i<n; i++) {
        scanf("%d", &a);
        if (CheckPrimeNumber(a) == true) {
            printf("%d la so nguyen to\n", a);
        }else
            printf("%d khong la so nguyen to\n", a);
    }
    
    return 0;
}
