//
//  main.cpp
//  IF_16
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <math.h>

int main(int argc, const char * argv[]) {
    int x, y, z, c;
    float p;
    scanf("%d %d %d", &x, &y, &z);
    c = x + y+ z;
    p = (float)c/2;
    if (x > 0 && y>0 && z>0 && x < y+z && y<x+z && z< x+y) {
        printf("%f",sqrt(p*(p-x)*(p-y)*(p-z)));
    }else
        printf("Khong phai la tam giac");
    
    return 0;
}
