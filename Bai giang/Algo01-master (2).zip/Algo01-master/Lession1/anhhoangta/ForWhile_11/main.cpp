//
//  main.cpp
//  ForWhile_11
//
//  Created by anhhoangta on 3/17/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n;
    scanf("%d", &n);
    doPrint(n - 1, ' ');
    doPrint(1, '*');
    doPrint(n - 1, ' ');
    printf("\n");
    for (int i = 2; i<n; i++) {
        doPrint(n - i, ' ');
        doPrint(1, '*');
        doPrint(2*i-3, ' ');
        doPrint(1, '*');
        doPrint(n - i , ' ');
        printf("\n");
    }
    doPrint(2*n-1, '*');
    return 0;
}
