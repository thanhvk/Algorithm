//
//  main.cpp
//  IF_21
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <math.h>

int main(int argc, const char * argv[]) {
    float a, b, c, delta;
    scanf("%f %f %f", &a, &b, &c);
    delta = powf(b, 2) - 4*a*c;
    if (delta < 0)
        printf("Phuong trinh vo nghiem");
    else if (delta == 0)
        printf("Phuong trinh co nghiem kep: %f", -b/(2*a));
    else
        printf("Phuong trinh co 2 nghiem phan biet: %f, %f", (-b + sqrt(delta))/(2*a), (-b - sqrt(delta))/(2*a));
    return 0;
}
