//
//  main.cpp
//  IF_14
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    int x, y, z;
    printf("Input three integer numbers\n");
    scanf("%d %d %d", &x, &y, &z);
    printf("%d la so lon nhat", (x > y)?((x > z)?x:z):((y < z)?z:y));
    return 0;
}
