//
//  main.cpp
//  IF_19
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int x, temp;
    scanf("%d", &x);
    temp = 1000 + 50*230;
    if (x <= 50)
        printf("Tong tien phai tra la: %d", temp + (x - 50)*230);
    else if (x <= 100)
        printf("Tong tien phai tra la: %d", temp + (x - 50)*480);
    else if (x < 150)
        printf("Tong tien phai tra la: %d", temp + (x - 50)*700);
    else
        printf("Tong tien phai tra la: %d", temp + (x - 50)*900);
    
    return 0;
}
