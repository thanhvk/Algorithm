//
//  main.cpp
//  IF_11
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int x, y;
    printf("Input two interger numbers\n");
    scanf("%d, %d", &x, &y);
    if (x == y) {
        printf("%d bang %d", x, y);
    } else
        printf("%d khac %d", x, y);
    return 0;
}
