//
//  main.cpp
//  ForWhile_8
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n;
    scanf("%d", &n);
    
    for (int i=1; i<=n; i++) {
        doPrint(n-i,' ');
        doPrint(2*i-1, '*');
        printf("\n");
    }
    return 0;
}
