//
//  main.cpp
//  IF_10
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int x, y;
    printf("Input two interger numbers\n");
    scanf("%d, %d", &x, &y);
    if (x > y) {
        printf("So lon nhat la: %d", x);
    } else if (x < y) {
        printf("So lon nhat la: %d", y);
    } else
        printf("Hai so bang nhau");
    return 0;
}
