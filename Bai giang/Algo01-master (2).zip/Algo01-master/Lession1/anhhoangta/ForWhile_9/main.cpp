//
//  main.cpp
//  ForWhile_9
//
//  Created by anhhoangta on 3/17/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int a, b;
    scanf("%d %d", &a, &b);
    doPrint(a, '*');
    printf("\n");
    
    for (int i=0; i<b-2; i++) {
        doPrint(1, '*');
        doPrint(a-2, ' ');
        doPrint(1, '*');
        printf("\n");
    }
    
    doPrint(a, '*');
    printf("\n");
    
    return 0;
}
