//
//  main.cpp
//  ForWhile_14
//
//  Created by anhhoangta on 3/17/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int x, y;
    scanf("%d %d", &x, &y);
    doPrint(y, '*');
    printf("\n");
    for (int i=1; i<x; i++) {
        doPrint((y-1)/2, ' ');
        doPrint(1, '*');
        doPrint((y-1)/2, ' ');
        printf("\n");
    }
    return 0;
}
