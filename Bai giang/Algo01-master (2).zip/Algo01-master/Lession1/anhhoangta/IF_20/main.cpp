//
//  main.cpp
//  IF_20
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    float a, b;
    scanf("%f %f", &a, &b);
    if (a == 0)
        if (b == 0)
            printf("Phuong trinh co vo so nghiem");
        else
            printf("Phuong trinh vo nghiem");
    else
        printf("Phuong trinh co 1 nghiem la: %f", -b/a);
    
    return 0;
}
