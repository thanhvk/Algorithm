//
//  main.cpp
//  ForWhile_13
//
//  Created by anhhoangta on 3/17/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    int n, S;
    S = 0;
    scanf("%d", &n);
    for (int i=0; i<4; i++) {
        S = S + fmod(n/(pow(10, i)),10);
    }
    printf("%d", S);
    return 0;
}
