//
//  main.cpp
//  ForWhile_12
//
//  Created by anhhoangta on 3/17/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
#include <string.h>

int main(int argc, const char * argv[]) {
    freopen("/Users/anhhoangta/Desktop/Buoi1_1/Home\ Work/ForWhile_12/labiec21.inp", "r", stdin);
    
    int min, n, m, a, b, count;
    scanf("%d", &n);
    
    for (int i=0; i<n; i++) {
        scanf("%d", &m);
        scanf("%d", &a);
        min = a;
        count = 1;
        for (int j=1; j<m; j++) {
            scanf("%d",&b);
            if (min > b){
                min = b;
                count =1;
            }else if (min == b)
                count += 1;
        }
        printf("%d %d\n", min, count);
    }
    return 0;
}
