//
//  main.cpp
//  ForWhile_1
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int x;
    scanf("%d", &x);
    for (int i=0; i<x; i++) {
        printf("Vi du su dung vong lap for\n");
    }
    return 0;
}
