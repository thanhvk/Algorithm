//
//  main.cpp
//  ForWhile_7
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
#include <fstream>
int main(int argc, const char * argv[]) {
    freopen("/Users/anhhoangta/Desktop/Buoi1_1/Home\ Work/ForWhile_7/labiec.inp", "r", stdin);
    int x;
    while (true) {
        scanf("%d", &x);
        if (x%10 != 0) {
            printf("%d ", x);
        }else
            break;
    }
    
    return 0;
}
