//
//  main.cpp
//  IF_18
//
//  Created by anhhoangta on 3/16/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int x;
    scanf("%d", &x);
    if (a >= 0) {
        if (a%2 == 0) {
            printf("%d la so chan", x);
        }else
            printf("%d la so le", x);
    }else
        printf("%d la so am", x);
    return 0;
}
