//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

int main25(int argc, const char * argv[]) {
    // insert code here...
    int a = 6,b=67;

    if (a>b) {
        int temp = a;
        a = b;
        b = temp;
    }
    for (int i = a; i<=b ; i++) {
        if (i%2==0) {
            printf("%d\n",i);
        }
    }
    return 0;
}


