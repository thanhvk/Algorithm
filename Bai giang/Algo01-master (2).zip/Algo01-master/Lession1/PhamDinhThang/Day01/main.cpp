//
//  main.cpp
//  Day01
//
//  Created by Pham Dinh Thang on 3/21/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//

#include <iostream>

int main0(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
