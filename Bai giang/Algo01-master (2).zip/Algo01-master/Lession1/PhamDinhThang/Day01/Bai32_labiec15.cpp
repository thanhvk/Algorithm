//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

void doPrint1(int number,char ch) {
    for (int i = 0; i<number; i++) {
        printf("%c",ch);
    }
}

int main32(int argc, const char * argv[]) {
    // insert code here...
    int h = 11;
    int charPerLine = 2*h-1;
    
    
    doPrint1((charPerLine-1)/2, ' ');
    doPrint1(1, '*');
    doPrint1((charPerLine-1)/2, ' ');
    printf("\n");
    for (int i =1; i<h-1; i++) {
        doPrint1((charPerLine-(2*i+1))/2, ' ');
        doPrint1(1, '*');
        doPrint1(2*i-1, ' ');
        doPrint1(1, '*');
        doPrint1((charPerLine-(2*i+1))/2, ' ');
        printf("\n");
    }
    doPrint1(charPerLine, '*');
    printf("\n");
    return 0;
}



