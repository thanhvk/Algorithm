//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main16(int argc, const char * argv[]) {
    // insert code here...
    float a,b,c;
    printf("a= ");
    scanf("%f",&a);
    printf("b= ");
    scanf("%f",&b);
    printf("c= ");
    scanf("%f",&c);
    if ((a+b>c)&&(a+c>b)&&(b+c>a)) {
        printf("a,b,c la 3 canh tam giac");
    } else {
        printf("a,b,c khong la 3 canh tam giac");
    }
    return 0;
}


