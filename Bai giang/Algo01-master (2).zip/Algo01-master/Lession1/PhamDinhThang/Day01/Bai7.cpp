//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main7(int argc, const char * argv[]) {
    // insert code here...
    float r;
    printf("Nhap ban kinh = ");
    scanf("%f",&r);
    printf("Dien tich xung quanh = %f\n",4*3.14156*r*r);
    printf("The tich = %f\n",4*3.14156*r*r*r/3);
    return 0;
}
