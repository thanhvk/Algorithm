//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

int main21(int argc, const char * argv[]) {
    // insert code here...
    float a,b,c;
    char line[80];
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai20input.txt", "rt");
    fgets(line, 80, file);
    sscanf (line, "%f", &a);
    fgets(line, 80, file);
    sscanf (line, "%f", &b);
    fgets(line, 80, file);
    sscanf (line, "%f", &c);
    
    
    float delta = b*b-4*a*c;
    if (delta < 0) {
        printf("PT vo nghiem\n");
    } else if (delta == 0) {
        printf("Nghiem kep = %f\n",-1*b/(2*a*c));
    } else {
        printf("Nghiem 1 = %f",-1*b-sqrt(delta)/(2*a));
        printf("Nghiem 2 = %f",-1*b-sqrt(delta)/(2*a));
    }
    
    return 0;
}


