//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main9(int argc, const char * argv[]) {
    // insert code here...
    int number=0;
    char line[80];
    
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai9input.txt", "rt");
    
    while(fgets(line, 80, file) != NULL) {
        sscanf (line, "%d", &number);
        printf ("number of sec = %d\n", number);
    }
    fclose(file);
    
    
    int hour = number/3600;
    int min = (number - hour*3600)/60;
    int sec = number - hour*3600 - min*60;
    printf("Time = %d h %d m %d s\n",hour,min,sec);
    return 0;
}


