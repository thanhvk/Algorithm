//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

int main26(int argc, const char * argv[]) {
    // insert code here...
    int a = 86;
    int sum = 0;
    for (int i = 0; i<=a ; i++) {
        if (i%2!=0) {
            sum = sum+i;
        }
    }
    printf("Sum = %d\n",sum);
    return 0;
}


