//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;
void doPrint0(int number,char ch) {
    for (int i = 0; i<number; i++) {
        printf("%c",ch);
    }
}

int main30(int argc, const char * argv[]) {
    // insert code here...
    int cao = 7;
    int rong = 10;
    
    //Cach 1
    for (int i = 0; i<cao; i++) {
        for (int j = 0; j <rong; j++) {
            if ((i==0)||(i==cao-1))
                printf("*");
            else if ((j==0)||(j==rong-1))
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    printf("\n");
    
    //Cach 2
    doPrint0(rong,'*');
    printf("\n");
    for (int i = 0; i<cao-2; i++) {
        doPrint0(1, '*');
        doPrint0(rong-2, ' ');
        doPrint0(1, '*');
        printf("\n");
    }
    doPrint0(rong,'*');
    printf("\n");
    return 0;
}




