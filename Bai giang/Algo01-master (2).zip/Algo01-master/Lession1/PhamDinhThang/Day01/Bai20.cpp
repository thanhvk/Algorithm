//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main20(int argc, const char * argv[]) {
    // insert code here...
    int a,b;
    char line[80];
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai20input.txt", "rt");
    fgets(line, 80, file);
    sscanf (line, "%d", &a);
    fgets(line, 80, file);
    sscanf (line, "%d", &b);
    if (a==0) {
        printf("Vo nghiem");
    } else {
        printf("a = %d,b=%d\n",a,b);
        printf("Nghiem ax+b = 0, x= %f\n",-1*(float)b/(float)a);
    }
    
    return 0;
}


