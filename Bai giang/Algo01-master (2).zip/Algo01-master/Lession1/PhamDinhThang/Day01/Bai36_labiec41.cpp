//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

void doPrint3(int number,char ch) {
    for (int i = 0; i<number; i++) {
        printf("%c",ch);
    }
}

int main36(int argc, const char * argv[]) {
    // insert code here...
    //draw the 'N' char
    int h = 21;
    for (int i = 0; i<h/2; i++) {
        doPrint3(i+1, '*');
        doPrint3((h/2-i)*2-1, ' ');
        doPrint3(i*2+1, '*');
        doPrint3(1+h/2-i, ' ');
        printf("\n");
    }
    doPrint3(h+h/2, '*');
    printf("\n");
    
    for (int i = h/2-1; i>=0; i--) {
        doPrint3(i+1, '*');
        doPrint3((h/2-i)*2-1, ' ');
        doPrint3(i*2+1, '*');
        doPrint3(1+h/2-i, ' ');
        printf("\n");
    }
    return 0;
}



