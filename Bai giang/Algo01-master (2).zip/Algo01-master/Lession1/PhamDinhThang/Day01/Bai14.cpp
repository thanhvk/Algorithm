//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main14(int argc, const char * argv[]) {
    // insert code here...
    float a,b,c;
    float max;
    printf("Nhap a = ");
    scanf("%f",&a);
    printf("Nhap b = ");
    scanf("%f",&b);
    printf("Nhap b = ");
    scanf("%f",&c);
    max = a;
    if (b>max) {
        max = b;
    }
    if (c>max) {
        max = c;
    }
    printf("Max = %f\n",max);
    return 0;
}


