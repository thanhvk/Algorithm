//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

int main22(int argc, const char * argv[]) {
    // insert code here...
    int n = 5;
    for (int i=0; i<n; i++) {
        printf("Vi du vong lap for\n");
    }
    return 0;
}


