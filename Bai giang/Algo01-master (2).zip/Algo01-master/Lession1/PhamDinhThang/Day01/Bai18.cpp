//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main18(int argc, const char * argv[]) {
    // insert code here...
    int number;
    char line[80];
    
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai18input.txt", "rt");
    fgets(line, 80, file);
    sscanf (line, "%d", &number);
    printf("number = %d\n",number);
    if (number < 0) {
        printf("So am\n");
    } else {
        if (number%2 ==0) {
            printf("So chan\n");
        } else {
            printf("So le\n");
        }
    }
    fclose(file);
    return 0;
}


