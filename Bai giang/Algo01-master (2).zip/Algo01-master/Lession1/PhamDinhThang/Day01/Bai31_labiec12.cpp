//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

bool checkPrime(int number);

int main31(int argc, const char * argv[]) {
    // insert code here...
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai31input.txt", "r");
    int i = 0;
    while (!feof (file)) {
        fscanf (file, "%d", &i);
        if (checkPrime(i)==true) {
            printf("%d\n",i);
        }
        
    }
    fclose (file);
    printf("\n");
    return 0;
    return 0;
}

bool checkPrime(int number) {
    int n = 0;
    for (int i = 1; i <= number; i++) {
        if (number%i ==0)
            n++;
        if (n>2) {
            return false;
        }
    }
    if (n == 2) {
        return true;
    } else return false;
    
}



