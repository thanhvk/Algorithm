//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main3(int argc, const char * argv[]) {
    // insert code here...
    int number;
    char line[80];
    
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai3input.txt", "rt");
    
    while(fgets(line, 80, file) != NULL) {
        /* get a line, up to 80 chars from file  done if NULL */
        sscanf (line, "%d", &number);
        /* convert the string to a long int */
        printf ("number = %d\n", number);
    }
    fclose(file);  /* close the file prior to exiting the routine */
    return 0;
}
