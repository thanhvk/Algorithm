//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

int main28(int argc, const char * argv[]) {
    // insert code here...
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai28input.txt", "r");
    int i = 0;
    while (!feof (file)) {
        fscanf (file, "%d", &i);
        if (i%10!=0) {
            printf ("%d ", i);
        } else {
            break;
        }
 
    }
    fclose (file);
    printf("\n");
    return 0;
}



