//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main8(int argc, const char * argv[]) {
    // insert code here...
    float r;
    printf("Nhap so = ");
    scanf("%f",&r);
    printf("Binh phuong = %f\n",r*r);
    printf("Lap phuong = %f\n",r*r*r);
    return 0;
}
