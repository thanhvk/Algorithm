//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main15(int argc, const char * argv[]) {
    // insert code here...
    int hour;
    int salary;
    char line[80];
    
    FILE* file = fopen ("/Users/mac/Desktop/CTDLGT_TechMaster/Day01/Day01/bai15input.txt", "rt");
    fgets(line, 80, file);
    sscanf (line, "%d", &hour);
    fgets(line, 80, file);
    sscanf (line, "%d", &salary);
    fclose(file);
    printf("Hour = %d, salary = %d\n",hour,salary);
    
    if (hour > 40) {
        printf("Tien luong = %d\n",40*salary+(hour-40)*2*salary);
    } else {
        printf("Tien luong = %d\n",hour*salary);
    }
    return 0;
}


