//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main17(int argc, const char * argv[]) {
    // insert code here...
    float a,b,c;
    float min,max,middle;
    printf("a= ");
    scanf("%f",&a);
    min = a;
    max = a;
    middle = a;
    printf("b= ");
    scanf("%f",&b);
    if (b>max) {
        max = b;
    }
    if (b<min) {
        min = b;
    }
    if (b>a) {
        middle = b;
    }
    printf("c= ");
    scanf("%f",&c);
    if (c>max) {
        max = c;
    }
    if (c<min) {
        min = c;
    }
    if (((a>=b)&&(b>=c))||((c>=b)&&(b>=a))) {
        middle = b;
    }
    if (((b>=a)&&(a>=c))||((c>=a)&&(a>=b))) {
        middle = a;
    }
    if (((b>=c)&&(c>=a))||((a>=c)&&(c>=b))) {
        middle = c;
    }
    printf("%f,%f,%f",min,middle,max);
    return 0;
}


