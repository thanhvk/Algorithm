//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main13(int argc, const char * argv[]) {
    // insert code here...
    float diem;
    printf("Nhap diem = ");
    scanf("%f",&diem);
    if (diem>9) {
        printf("Loai xuat sac\n");
    } else if ((diem>8)&&(diem<=9)) {
        printf("Loai gioi\n");
    } else if ((diem>7)&&(diem<=8)) {
        printf("Loai kha\n");
    } else if ((diem>6)&&(diem<=7)) {
        printf("Loai trung binh\n");
    } else if ((diem>5)&&(diem<=6)) {
        printf("Loai yeu\n");
    } else {
        printf("Loai kem\n");
    }
    return 0;
}


