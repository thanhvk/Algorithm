//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

int main(int argc, const char * argv[]) {
    // insert code here...
    int n;
    int tong=0;
    int temp;
    printf("Nhap n = ");
    scanf("%d",&n);
    for (int i = 0; i<n ; i++) {
        printf("Nhap so = ");
        scanf("%d",&temp);
        tong = tong + temp;
    }
    printf("Tong = %d\n",tong);
    return 0;
}



