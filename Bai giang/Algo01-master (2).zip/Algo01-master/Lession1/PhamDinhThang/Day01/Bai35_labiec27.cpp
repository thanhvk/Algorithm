//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

void doPrint2(int number,char ch) {
    for (int i = 0; i<number; i++) {
        printf("%c",ch);
    }
}

int main35(int argc, const char * argv[]) {
    // insert code here...
    //draw the 'N' char
    int size = 10;
    for (int i = 0; i<size; i++) {
        for (int j = 0; j<size; j++) {
            if ((i==j)||(j==0)||(j==size-1)) {
                printf("*");
            } else printf(" ");
        }
        printf("\n");
    }
    return 0;
}



