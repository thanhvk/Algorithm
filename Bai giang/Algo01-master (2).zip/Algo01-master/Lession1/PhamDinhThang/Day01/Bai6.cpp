//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main6(int argc, const char * argv[]) {
    // insert code here...
    float r;
    printf("Nhap ban kinh = ");
    scanf("%f",&r);
    printf("Dien tich = %f\n",2*3.14156*r);
    return 0;
}
