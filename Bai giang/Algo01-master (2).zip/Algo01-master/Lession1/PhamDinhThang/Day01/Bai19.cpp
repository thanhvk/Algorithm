//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main19(int argc, const char * argv[]) {
    // insert code here...
    int sodien = 234;
    if (sodien <=50) {
        printf("Tien dien = %d VND\n",sodien*230);
    } else if (sodien <= 100) {
        printf("Tien dien = %d VND\n",50*230+(sodien-50)*480);
    } else if (sodien <= 150) {
        printf("Tien dien = %d VND\n",50*230+50*480+(sodien-100)*700);
    } else {
        printf("Tien dien = %d VND\n",50*230+50*480+50*700+(sodien-150)*900);
    }
    return 0;
}


