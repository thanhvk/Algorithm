//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>

using namespace std;

int main10(int argc, const char * argv[]) {
    // insert code here...
    int a,b;
    printf("Nhap a = ");
    scanf("%d",&a);
    printf("Nhap b = ");
    scanf("%d",&b);
    if (a>b) {
        printf("So lon nhat la a");
    } else if (a==b) {
        printf("Hai so bang nhau");
    } else {
        printf("So lon nhat la b");
    }
    return 0;
}


