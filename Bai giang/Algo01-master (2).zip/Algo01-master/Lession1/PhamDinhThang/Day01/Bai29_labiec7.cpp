//
//  main.cpp
//  DemoCPP
//
//  Created by Pham Dinh Thang on 3/15/16.
//  Copyright © 2016 Pham Dinh Thang. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string.h>
#include <math.h>

using namespace std;

int main29(int argc, const char * argv[]) {
    // insert code here...
    int h = 11;
    int charPerLine = 2*h-1;
    for (int i =0; i<h; i++) {
        for (int j =0; j<(charPerLine-(2*i+1))/2; j++) {
            printf(" ");
        }
        for (int j =0; j<(2*i+1); j++) {
            printf("*");
        }
        for (int j =0; j<(charPerLine-(2*i+1))/2; j++) {
            printf(" ");
        }
        printf("\n");
    }
    return 0;
}



