#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>

using namespace std;

int main()
{
    int x;

    scanf("%d", &x);

    for (int i = 0; i < x; i++) {
        printf("Vi du su dung vong lap for\n");
    }

    getchar();
    return 0;
}
