#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h> // tuong duong conio.h trong win

using namespace std;

int main()
{
    printf("Hello\n");
    return 0;
}
