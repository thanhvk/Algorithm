/* Bai 11 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int a, b;
	scanf("%d %d",&a,&b);
	if(a == b){
		printf("%d bang %d",a,b);
	}else{
		printf("%d khac %d",a,b);
	}
	
	getch();
	return 0;
}
