/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int a, b;
	scanf("%d %d",&a,&b);
	for(int i = a; i <= b; i++){
		printf("%d\n",i);
	}
	
	getch();
	return 0;
}
