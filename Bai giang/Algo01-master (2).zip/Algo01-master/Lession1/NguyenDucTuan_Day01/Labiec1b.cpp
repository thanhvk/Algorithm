/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int n, tong;
	tong = 0;
	scanf("%d",&n);
	for(int i = 1; i <= n; i++){
		tong = tong + i; 
	}
	printf("%d\n",tong);
	
	getch();
	return 0;
}
