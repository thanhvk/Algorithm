/* Bai 26 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int n, tong;
	tong = 0;
	scanf("%d",&n);
	for(int i = 0; i <= n; i++){
		if((i % 2) != 0){
			tong = tong + i; 
		}
	}
	printf("%d\n",tong);
	
	getch();
	return 0;
}
