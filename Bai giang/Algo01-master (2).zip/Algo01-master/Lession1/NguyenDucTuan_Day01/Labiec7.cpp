/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void doPrint(int soLuong,char kyTu){

	for(int k = 0; k < soLuong; k++){
		printf("%c",kyTu);
	}
}

int main(){
	int n,soTrong;
	freopen("File/Labiec7.inp","r",stdin);
	scanf("%d",&n);
	soTrong = n - 1;
	
	for(int i = 1; i <= n; i++){ 
		int soSao = i * 2 - 1;
		
		doPrint(soTrong,' ');
		doPrint(soSao,'*');
		
		soTrong--;
		printf("\n");
	}
	
	getch();
	return 0;
}
