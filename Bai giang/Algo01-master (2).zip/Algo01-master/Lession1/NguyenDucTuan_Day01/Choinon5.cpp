/* Bai 14 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int findMax(int &a, int &b, int &c){
	int max_tempt;
	max_tempt = a;
	if(b > max_tempt){
		max_tempt = b;
	}
	if(c > max_tempt){
		max_tempt = c;
	}
	return max_tempt;
}

int main(){
	int a, b, c, max;
	scanf("%d %d %d",&a,&b,&c);
	max = findMax(a,b,c);
	printf("So lon nhat = %d",max);
	
	getch();
	return 0;
}
