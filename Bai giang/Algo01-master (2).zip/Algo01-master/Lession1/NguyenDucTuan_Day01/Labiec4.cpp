/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	
	while(true){
		int tempt;
		scanf("%d",&tempt);
		if((tempt % 10) == 0){
			break;
		}
		printf("%d ",tempt);
	}
	
	getch();
	return 0;
}
