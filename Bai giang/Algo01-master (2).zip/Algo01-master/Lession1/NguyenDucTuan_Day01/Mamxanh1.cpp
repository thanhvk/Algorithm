/* Bai 1 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	printf("Hello\n");

	getch();
	return 0;
}
