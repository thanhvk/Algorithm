/* Bai 7 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int r;
	float pi, dienTich, theTich;
	pi = 3.14;
	
	printf("Nhap ban kinh hinh cau: \n");
	scanf("%d",&r);
	
	dienTich = 4 * pi * r * r;
	theTich = (4 * pi * r * r * r)/3;
	printf("Dien tich hinh cau la: %f\n",dienTich);
	printf("The tich hinh cau la: %f\n",theTich);
	
	getch();
	return 0;
}
