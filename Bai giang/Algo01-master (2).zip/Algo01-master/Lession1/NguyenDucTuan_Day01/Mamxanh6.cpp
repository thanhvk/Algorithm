/* Bai 6 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int r;
	float pi, dienTich;
	pi = 3.14;
	
	printf("Nhap ban kinh hinh tron: \n");
	scanf("%d",&r);
	
	dienTich = pi * r * r;
	printf("Dien tich hinh tron la: %f\n",dienTich);
	
	getch();
	return 0;
}
