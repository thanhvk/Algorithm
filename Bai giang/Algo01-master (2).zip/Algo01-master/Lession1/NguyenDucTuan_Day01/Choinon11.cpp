/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void giaiPtBac1(int &a, int &b){
	if(a == 0 && b != 0){
		printf("Phuong trinh da cho vo nghiem.\n");
	}else if(a == 0 && b == 0){
		printf("Phuong trinh da cho co vo so nghiem.\n");
	}else{
		float x = -(float)b/a;
		printf("Phuong trinh da cho co 1 nghiem x = %f",x);
	}
}

int main(){
	freopen("File/Choinon11.inp","r",stdin);

	int a, b;
	scanf("%d %d",&a,&b);
	
	giaiPtBac1(a,b);
	
	getch();
	return 0;
}
