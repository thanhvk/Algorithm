/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int tinhLuong(int &soGio, int &luongGio){
	int luong_tempt;

	if(soGio > 40){
		luong_tempt = ((soGio - 40) * (luongGio * 2)) + (40 * luongGio);
	}else{
		luong_tempt = soGio * luongGio;
	}
	return luong_tempt;
}

int main(){
	freopen("File/Choinon6.inp","r",stdin);
	int soGio, luongGio, luong;
	scanf("%d %d",&soGio,&luongGio);
	luong = tinhLuong(soGio,luongGio);
	printf("%d",luong);
	
	getch();
	return 0;
}
