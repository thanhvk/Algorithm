/* Bai 10 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int findMax(int &a, int &b){
	if(a >= b){
		return a;
	}else {
		return b;
	}
}

int main(){
	int a, b, max;
	scanf("%d %d",&a,&b);
	max = findMax(a,b);
	printf("So lon nhat = %d",max);
	
	getch();
	return 0;
}
