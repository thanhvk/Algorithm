/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

int main(){

	int n,min,count;
	scanf("%d",&n);
	
	min = 0;
	count = 0;
	for(int i = 0; i < n; i++){
		int tempt;
		
		scanf("%d",&tempt);
		if(i == 0){
			min = tempt;
			count++;
		}else{
			if(tempt < min){
				min = tempt;
				count = 1;
			}
			if(tempt == min){
				count++;
			}
		}
	}
	
	printf("%d %d\n",min,count);
	
	getch();
	return 0;
}
