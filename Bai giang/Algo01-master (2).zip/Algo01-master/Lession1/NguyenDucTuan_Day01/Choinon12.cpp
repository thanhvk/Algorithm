/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

void giaiPtBac2(int &a, int &b, int &c){
	float delta = (float)(b * b) - (4 * a * c);
	if(delta < 0){
		printf("Phuong trinh da cho vo nghiem.\n");
	}else if (delta == 0){
		float x0 = -(float)b/(2 * a);
		printf("Phuong trinh da cho co nghiem kep x1 = x2 = %f",x0);
	}else{
		float x1 = (-b + sqrt(delta))/(2 * a);
		float x2 = (-b - sqrt(delta))/(2 * a);
		printf("Phuong trinh da cho co 2 nghiem x1 = %f va x2 = %f",x1,x2);
	}
}

int main(){
	freopen("File/Choinon12.inp","r",stdin);

	int a, b, c;
	scanf("%d %d %d",&a,&b,&c);
	
	giaiPtBac2(a,b,c);
	
	getch();
	return 0;
}
