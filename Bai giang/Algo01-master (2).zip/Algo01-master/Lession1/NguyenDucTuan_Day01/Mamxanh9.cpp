/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	freopen("File/Mamxanh9.inp", "r", stdin);
	int sTotal, h, m, s;
	
	scanf("%d",&sTotal);
	
	h = sTotal/3600;
	m = (sTotal % 3600) / 60;
	s = (sTotal % 3600) % 60;
	
	printf("So s trong file: %d\n",sTotal);
	printf("Chuyen thanh %d:%d:%d",h,m,s);
	
	getch();
	return 0;
}
