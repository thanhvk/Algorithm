/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int tinhTienDien(int &soDien){
	// Tien thue bao dien ke 1000/thang
	
	int dinhMuc = 50;
	int tien_tempt;

	if(soDien > dinhMuc){
		int vuotDm = soDien - dinhMuc;
		if(vuotDm < 50){
			// gia: 480/KW
			tien_tempt = soDien * 480 + 1000;
		}else if(vuotDm > 50 && vuotDm < 100){
			// gia: 700/KW
			tien_tempt = soDien * 700 + 1000;
		}else{
			// gia: 900/KW
			tien_tempt = soDien * 900 + 1000;
		}
	}else{
		// soDien <= dinhMuc thi gia: 230/KW
		tien_tempt = dinhMuc * 230 + 1000;
	}
	
	return tien_tempt;
}

int main(){
	freopen("File/Choinon10.inp","r",stdin);

	int soDien, tien;
	scanf("%d",&soDien);
	tien = tinhTienDien(soDien);
	printf("s0 = %d",tien);
	
	getch();
	return 0;
}
