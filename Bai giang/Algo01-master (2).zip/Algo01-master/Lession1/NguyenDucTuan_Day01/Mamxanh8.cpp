/* Bai 8 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int a, binhPhuong, lapPhuong;
	
	printf("Nhap so a : \n");
	scanf("%d",&a);
	
	binhPhuong = a * a;
	lapPhuong = a * a * a;
	// lapPhuong = binhPhuong * a;
	printf("Binh phuong cua %d la: %d\n",a,binhPhuong);
	printf("Lap phuong cua %d la: %d\n",a,lapPhuong);
	
	getch();
	return 0;
}
