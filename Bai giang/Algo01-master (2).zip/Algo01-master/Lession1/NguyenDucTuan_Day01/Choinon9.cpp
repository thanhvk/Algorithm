/* Bai 18 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	freopen("File/Choinon9.inp","r",stdin);
	int a;
	scanf("%d",&a);
	if(a >= 0){
		if((a % 2) == 0){
			printf("%d la so chan",a);
		}else{
			printf("%d la so le",a);
		}
	}else{
		printf("%d la so am",a);
	}
	
	getch();
	return 0;
}
