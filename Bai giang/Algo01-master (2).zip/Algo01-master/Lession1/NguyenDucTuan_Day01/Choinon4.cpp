/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void printXepLoai(float &point){
	if(point >= 9){
		printf("Xuat sac");
	}else if(point >= 8 && point < 9){
		printf("Gioi",point);
	}else if(point >= 7 && point < 8){
		printf("Kha",point);
	}else if(point >= 6 && point < 7){
		printf("TBKha",point);
	}else if(point >= 5 && point < 6){
		printf("Tbinh",point);
	}else{
		printf("Yeu",point);
	}
}

int main(){
	float point;
	scanf("%f",&point);
	printXepLoai(point);
	
	getch();
	return 0;
}
