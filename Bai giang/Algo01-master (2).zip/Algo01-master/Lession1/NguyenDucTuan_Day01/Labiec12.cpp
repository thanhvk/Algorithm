/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

bool checkSoNguyenTo(int &so){
	
	int can = sqrt((float)so);
	for(int k = 2; k <= can; k++){
		if((so % k) == 0){
			return false;
		}
	}
	return true;
}

int main(){
	int n;
	scanf("%d",&n);
	for(int i = 0; i < n; i++){
		int tempt;
		scanf("%d",&tempt);
		if(checkSoNguyenTo(tempt)){
			printf("%d la so nguyen to \n",tempt);
		}else{
			printf("%d khong phai la so nguyen to \n",tempt);
		}
	}
	
	getch();
	return 0;
}
