/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int n, tong;
	tong = 0;
	scanf("%d",&n);
	for(int i = 0; i < n; i++){
		int tempt;
		scanf("%d",&tempt);
		tong = tong + tempt;
	}
	
	printf("%d",tong);
	
	getch();
	return 0;
}
