/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>


int main(){
	freopen("File/Mamxanh4.inp","r",stdin);
	int a,b;
	scanf("%d %d",&a,&b);
	printf("So thu nhat o file la: %d\n",a);
	printf("So thu hai o file la: %d\n",b);
		
	getch();
	return 0;
}
