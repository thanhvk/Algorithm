/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void doPrint(int soLuong,char kyTu){

	for(int k = 0; k < soLuong; k++){
		printf("%c",kyTu);
	}
}

int main(){
	int a, soTrong1,soTrong2;
	freopen("File/Labiec15.inp","r",stdin);
	scanf("%d",&a);
	
	soTrong1 = a - 1;
	// dong dau tien
	doPrint(soTrong1,' ');
	doPrint(1,'*');
	printf("\n");
	// khuc giua
	for(int i = 1; i <= a - 2; i++){
		soTrong1--;
		soTrong2 = i + (i - 1);
		doPrint(soTrong1,' ');
		doPrint(1,'*');
		doPrint(soTrong2,' ');
		doPrint(1,'*');
		
		printf("\n");
	}
	// dong cuoi cung
	doPrint(a * 2 - 1,'*');
	printf("\n");
	
	getch();
	return 0;
}
