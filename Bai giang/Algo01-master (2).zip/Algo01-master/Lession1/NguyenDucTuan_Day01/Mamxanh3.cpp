/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	freopen("File/Mamxanh3.inp","r",stdin);
	int n;
	scanf("%d",&n);
	
	printf("So o file la: %d\n",n);
	
	getch();
	return 0;
}
