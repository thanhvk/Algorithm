/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	
	int a,du,tong;
	scanf("%d",&a);
	tong = 0;
	
	do{
		du = a%10;
		tong = tong + du;
		a = a/10;
	}
	while(du != 0);
	
	printf("%d",tong);
	
	getch();
	return 0;
}
