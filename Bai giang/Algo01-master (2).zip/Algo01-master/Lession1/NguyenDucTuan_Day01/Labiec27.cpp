/* Ve chu P */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void doPrint(int soLuong,char kyTu){
	
	for(int k = 1; k <= soLuong; k++){
		printf("%c",kyTu);
	}
}

int main(){
	int a,b;
	freopen("File/Labiec27.inp","r",stdin);
	scanf("%d %d",&a,&b);
	
	// dong dau
	doPrint(a - 1,'*');
	printf("\n");
	// doan giua 1
	for(int i = 0; i < b/2; i++){
		doPrint(1,'*');
		doPrint(a - 2,' ');
		doPrint(1,'*');
		printf("\n");
	}
	// dong giua
	doPrint(a - 1,'*');
	printf("\n");
	// doan cuoi
	for(int m = 0; m < b/2; m++){
		doPrint(1,'*');
		printf("\n");
	}
	
	getch();
	return 0;
}
