/* Ve ca vang */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void doPrint(int soLuong,char kyTu){
	
	for(int k = 1; k <= soLuong; k++){
		printf("%c",kyTu);
	}
}

int main(){
	int a,trong;
	freopen("File/Labiec41.inp","r",stdin);
	scanf("%d",&a);
	
	// doan dau
	for(int i = 1; i <= a/2; i++){
		trong = a - 2 * i;
		doPrint(i,'*');
		doPrint(trong,' ');
		doPrint(i + i - 1,'*');
	
		printf("\n");
	}
	
	// dong giua
	doPrint(a + a/2,'*');
	printf("\n");
	
	// doan cuoi
	trong = 1;
	for(int m = a/2; m >= 1; m--){
		trong = a - 2 * m;
		doPrint(m,'*');
		doPrint(trong,' ');
		doPrint(m + m - 1,'*');
	
		printf("\n");
	}
	
	getch();
	return 0;
}
