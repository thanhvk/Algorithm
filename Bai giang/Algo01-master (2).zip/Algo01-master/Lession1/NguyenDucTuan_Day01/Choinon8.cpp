/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

// C1

int main(){
	int a, b ,c ,min3So;

	scanf("%d %d %d",&a,&b,&c);
	
	if(a < b){
		if(a < c){
			if(c > b){
				printf("%d %d %d",a,b,c);
			}else{
				printf("%d %d %d",a,c,b);	
			}
		}else{
			printf("%d %d %d",c,a,b);	
		}	
	}
	if(b < a){
		if(b < c){
			if(a > c){
				printf("%d %d %d",b,a,c);	
			}else{
				printf("%d %d %d",b,c,a);	
			}		
		}else{
			printf("%d %d %d",c,b,a);	
		}
	}
		
	getch();
	return 0;
}

/* C2
void sort(int arr[], int &n){
	
	for(int i = 0; i < n - 1; i++){
		for(int k = i + 1; k < n; k++){
			if(arr[k] < arr[i]){
				int tempt = arr[i];
				arr[i] = arr[k];
				arr[k] = tempt;
			}	
		}
	}
}

int main(){
	int n = 3;
	int arr[n];
	scanf("%d %d %d",&arr[0],&arr[1],&arr[2]);
	sort(arr,n);	

	printf("%d %d %d",arr[0],arr[1],arr[2]);
	
	getch();
	return 0;
}
*/
