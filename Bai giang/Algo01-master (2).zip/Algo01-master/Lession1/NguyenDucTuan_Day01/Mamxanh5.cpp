/* Bai 5 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	int  a, b, c;
	printf("Nhap vao 2 so nguyen a va b: \n");
	scanf("%d %d",&a,&b);
	
	c = a + b;
	printf("Tong 2 so la: %d\n",c);
	
	getch();
	return 0;
}
