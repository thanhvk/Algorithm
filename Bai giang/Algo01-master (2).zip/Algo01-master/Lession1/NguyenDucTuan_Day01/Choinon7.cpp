/* Bai 16 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>

float tinhDienTichTamGiac(int &a, int &b, int &c){
	float p = ((float)a+b+c) / 2;
	float s = sqrt(p * (p - a) * (p - b) * (p - c));
	
	return s;
}

bool checkTamGiac(int &a, int &b, int &c){
	if(((a+b)>c) && ((a+c)>b) && ((b+c)>a)){
		return true;
	}else{
		return false;
	}
}

int main(){
	
	int a,b,c,chuVi,dienTich;
	scanf("%d %d %d",&a,&b,&c);
	
	if(checkTamGiac(a,b,c)){
		printf("Dien tich tam giac: %f",tinhDienTichTamGiac(a,b,c));
	}else{
		printf("Khong phai la tam giac");	
	}
	
	getch();
	return 0;
}
