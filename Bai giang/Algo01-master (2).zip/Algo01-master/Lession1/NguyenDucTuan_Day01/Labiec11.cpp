/* */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void doPrint(int soLuong,char kyTu){
	
	for(int k = 1; k <= soLuong; k++){
		printf("%c",kyTu);
	}
}

int main(){
	int a,b;
	freopen("File/Labiec11.inp","r",stdin);
	scanf("%d %d",&a,&b);
	// dong dau
	doPrint(a,'*');
	printf("\n");
	// doan giua
	for(int i = 0; i < b - 2; i++){
		doPrint(1,'*');
		doPrint(a-2,' ');
		doPrint(1,'*');
		printf("\n");
	}
	// doan cuoi
	doPrint(a,'*');
	printf("\n");
	
	getch();
	return 0;
}
