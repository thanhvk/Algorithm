/* Bai 2 */
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

int main(){
	printf("Hello\n");
	printf("Cong hoa xa hoi chu nghia Viet Nam\n");
	printf("Doc lap * Tu do * Hanh phuc\n");
	
	getch();
	return 0;
}
