#include <stdio.h>
#include <stdlib.h>



int main(int argc, char *argv[]) {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int giolam, tienluong;
	scanf("%d %d", &giolam, &tienluong);
	
	if(giolam > 40){
		tienluong = ((giolam - 40)*tienluong * 2) + 40*tienluong;
		printf("tieng luong bang : %d", tienluong);
		return 0;
	}
	printf("tien luong bang : %d", giolam*tienluong);
	return 0;
}
