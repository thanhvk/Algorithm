#include <stdio.h>
#include <stdlib.h>

#define TRUE 	1
#define FALSE 	0
#define bool 	int

bool CheckBang(int a, int b){
	if(a == b ) return 1;
	return 0;
}

bool CheckLonHon(int a, int b){
	if(a > b) return 1;
	return 0;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int a,b;
	scanf("%d %d", &a, &b);
	
	if(CheckBang(a,b)){
		printf("%d bang %d",a,b);
		return 0;
	}
	if(CheckLonHon(a,b)){
		printf("%d lon hon %d",a,b);
		return 0;
	}
	printf("%d nho hon %d", a,b);
	return 0;
}
