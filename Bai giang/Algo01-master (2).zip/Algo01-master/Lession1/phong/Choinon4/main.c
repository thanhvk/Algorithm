#include <stdio.h>
#include <stdlib.h>

#define TRUE 	1
#define FALSE	0
#define bool 	int

bool checkDiem(float k1 , float k2, float diem){
	if(diem >= k1 && diem < k2) return 1;
	
	return 0;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	float diem;
	
	scanf("%f",&diem);
	
	if(checkDiem(9,10,diem)) {
		printf("Xuat xac");
		return 0;
	}
	if(checkDiem(8,9,diem)){
		printf("Gioi");
		return 0;
	}
	if(checkDiem(7,8,diem)){
		printf("Kha");
		return 0;
	}
	if(checkDiem(6,7,diem)){
		printf("TB Kha");
		return 0;
	}
	if(checkDiem(5,6,diem)){
		printf("Trung Binh");
		return 0;
	}
	if(checkDiem(0,5,diem)){
		printf("Yeu qua");
		return 0;
	}
	
	return 0;
}
