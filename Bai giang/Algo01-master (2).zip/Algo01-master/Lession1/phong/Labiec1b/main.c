#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int i, n, tong;
	
	scanf("%d",&n);
	for(i = 0; i < n; i++){
		tong += i; 
	}
	printf("%d", tong);
	return 0;
}
