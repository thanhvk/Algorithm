#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int i, n, item, tong = 0;
	
	scanf("%d", &n);
	for(i = 0; i< n; i++){
		scanf("%d", &item);
		tong += item;
	}
	printf("%d",tong);
	return 0;
}
