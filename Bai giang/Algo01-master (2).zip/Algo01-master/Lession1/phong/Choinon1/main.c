#include <stdio.h>
#include <stdlib.h>

#define TRUE	1
#define FALSE	0
#define bool int

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
bool Check(int a, int b){
	if(a > b) return 1;
	return 0;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int a,b;
	scanf("%d %d", &a,&b);
	
	if(Check(a,b)){
		printf("%d lon hon %d", a, b);
		return 0;
	}	
	printf("%d khong lon hon %d", a, b);
	return 0;
}
