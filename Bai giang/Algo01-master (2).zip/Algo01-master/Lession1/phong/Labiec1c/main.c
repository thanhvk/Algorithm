#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define TRUE 	1;
#define FALSE	0;
#define bool 	int;

bool checkChan(int a){
	if(a % 2 == 0) return 1;
	return 0;
}

int main(int argc, char *argv[]) {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int a, b, i;
	scanf("%d %d", &a, &b);
	
	for(i = a; i< b; i++){
		if(checkChan(i))printf("%d \n", i);
	}
	
	return 0;
}
