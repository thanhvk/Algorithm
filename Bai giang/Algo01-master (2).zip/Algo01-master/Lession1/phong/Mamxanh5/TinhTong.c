#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int a,b;
	scanf("%d %d", &a, &b);
	
	printf("Tong hai so la : %d", a+b);
	
	return 0;
}
