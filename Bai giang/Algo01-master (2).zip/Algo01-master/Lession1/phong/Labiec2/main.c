#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define TRUE 	1
#define FALSE	0
#define	bool 	int

bool CheckLe(int a){
	if(a % 2 != 0) return 1;
	return 0;
}

int main(int argc, char *argv[]) {
	
	freopen("file.inp","r",stdin);
	freopen("file.uot","w",stdout);
	
	int n,i,tong;
	
	scanf("%d",&n);
	
	for(i = 0; i < n; i++){
		if(CheckLe(i)) tong += i;
	}
	printf("%d", tong);
	return 0;
}
