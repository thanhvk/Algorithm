//#include <iostream>
//#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	int a;
	scanf("%d",&a);
	printf("%d",a);
	
	//getch();
	return 0;
}
