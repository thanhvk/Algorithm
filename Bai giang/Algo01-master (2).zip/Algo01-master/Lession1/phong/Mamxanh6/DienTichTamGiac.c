#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	int r;
	float pi = 3.14, s;
	scanf("%d",&r);
	printf("Dien tich hinh trong la : %f", 4 * pi * r*r );
	return 0;
}
