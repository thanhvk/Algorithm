#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */



int main() {
	
	freopen("file.inp","r",stdin);
	freopen("out.inp","w",stdout);
	
	int a,b;
	
	scanf("%d %d", &a, &b);
	printf("So thu nhat la : %d \n", a);
	printf("So thu hai la : %d", b);
		
	return 0;
}
