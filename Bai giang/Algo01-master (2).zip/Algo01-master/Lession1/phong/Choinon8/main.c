#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int CheckSoNho(int i, int j){
	if(i < j) return i;
	return j;
}

int CheckSoLon(int i, int j){
	if(i > j) return i;
	return j;
}

int main(int argc, char *argv[]) {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	int a,b,c;
	scanf("%d %d %d",&a ,&b, &c);
	int max = CheckSoLon(CheckSoLon(a,b),c), min = CheckSoNho(CheckSoNho(a,b),c);
	
	printf("%d ",min);
	
	if(a != min && a != max )
	printf("%d ",a);
	
	if(b != min && b != max )
	printf("%d ",a);
	
	if(c != min && c != max )
	printf("%d ",a);
	
	printf("%d ",max);
	
	return 0;
}
