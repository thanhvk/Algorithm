#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

const int _binhPhuong = 2;
const int _lapPhuong = 3;

int BinhPhuong(int n){
	int i, a = n;
	for(i = 1; i < _binhPhuong; i++){
		n *= a;
	}
	return n;
}

int LapPhuong(int n){
	int i, a = n;
	for(i = 1; i < _lapPhuong; i++){
		n *= a;
	}
	return n;
}

int main() {
	
	// doc file 
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int a;
	scanf("%d", &a);
	
	printf("Binh phuong cua %d la : %d \n", a, BinhPhuong(a));
	printf("Lap phuong cua %d la : %d", a, LapPhuong(a));
	
	return 0;
}
