#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

#define TRUE 	1;
#define FALSE 	0;
#define bool 	int;


const int dienke = 1000;
const int giaDm1 = 230;
const int giaDm2 = 480;
const int giaDm3 = 700;
const int giaDm4 = 900;


bool CheckDinhMuc(int a, int b, int c){
	if(c > b && c < b) return 1;
	return 0;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int sodien, sodienVuot;
	int thanhtoan;
	
	scanf("%d",&sodien);
	if(sodien > 50){
		sodienVuot = sodien - 50;
	}
	
	if(CheckDinhMuc(0,51,sodienVuot)){
		thanhtoan = dienke + (sodien - sodienVuot)*giaDm1 + sodienVuot*giaDm2;
		printf("%d", thanhtoan);
		return 0;
	}
	if(CheckDinhMuc(50,100,sodienVuot)){
		thanhtoan = dienke + (sodien - sodienVuot)*giaDm1 + sodienVuot*giaDm3;
		printf("%d", thanhtoan);
		return 0;
	}
	if(CheckDinhMuc(99,10000,sodienVuot)){
		thanhtoan = dienke + (sodien - sodienVuot)*giaDm1 + sodienVuot*giaDm4;
		printf("%d", thanhtoan);
		return 0;
	}
	thanhtoan = dienke + sodien*giaDm1;
	printf("%d VND",thanhtoan);
	return 0;
}
