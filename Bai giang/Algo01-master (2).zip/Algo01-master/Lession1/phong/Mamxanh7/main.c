#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

const float pi = 3.14;

float DienTich(int r){
	return r * r * 4 * pi;
}

float TheTich(int r){
	return 4/3 * r*r*r * pi;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int r ;
	
	scanf("%d", &r);
	printf("Dien tich hinh cau la : %f \n", DienTich(r));
	printf("The tich hinh cau la : %f", TheTich(r));
	
	return 0;
}
