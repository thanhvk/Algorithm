#include <stdio.h>
#include <stdlib.h>

#define TRUE 	1
#define FALSE	0
#define bool 	int

bool CheckBang(int a, int b){
	if(a == b) return 1;
	return 0;
}

bool CheckNhoHon(int a, int b){
	if(a < b) return 1;
	return 0;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int item, min , count;
	scanf("%d",&item);
	min = item;
	count = 1;
	while(1){
		scanf("%d",&item);
		if(item == 0) break;
		if(CheckBang(min,item)) count++;
		if(!CheckNhoHon(min,item) && !CheckBang(min,item)){
			min = item;
			count = 1;	
		}	
	}
	printf("So nho nhat : %d \n", min);
	printf("So lan lap : %d", count);
	return 0;
}
