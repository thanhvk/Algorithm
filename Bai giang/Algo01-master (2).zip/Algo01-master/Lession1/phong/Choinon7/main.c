#include <stdio.h>
#include <stdlib.h>

#define TRUE 	1
#define FALSE 	0
#define bool 	int

bool CheckTamGiac(int a, int b, int c){
	if(a == b  || a == c || b == c) return 0;
	return 1;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int a,b,c;
	scanf("%d %d %d", &a,&b,&c);
	float s;
	
	if(CheckTamGiac(a,b,c)){
		// ap dung cong thuc heron
		float p = (a + b + c)/2;
		s = sqrt(p*(p - a)*(p - b)*(p - c));
		
		printf("Dien tich tam giac bang %f", s);
		return 0;
	}
	printf("Khong phai la tam giac");
	
	return 0;
}
