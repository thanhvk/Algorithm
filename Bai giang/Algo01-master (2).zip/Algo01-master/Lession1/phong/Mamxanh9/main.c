#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.out","w",stdout);
	
	int gio, phut, giay;
	scanf("%d",&giay);
	if(giay < 0 || giay > 86399) return 0;
	gio = giay / 3600;
	phut = (giay - gio*3600) / 60;
	giay = giay - (gio * 3600) - phut * 60;
	
	printf("Hien tai la  %d gio : %d phut : %d giay",gio, phut, giay);
		
	return 0;
}
