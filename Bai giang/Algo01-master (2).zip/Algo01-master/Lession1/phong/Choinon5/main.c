#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */


// Cach 1
int CheckSoLon(int i , int j){
	if(i > j) return i;
	return j;
}

int main() {
	
	freopen("file.inp","r",stdin);
	freopen("file.uot","w",stdout);
	
	int a,b,c;
	scanf("%d %d %d", &a, &b, &c);
	printf("%d la so lon nhat",CheckSoLon(CheckSoLon(a,b),c));
	return 0;
}


// Cach 2

//int CheckNumber(int a , int b, int c){
//	if(a > b){
//		if(a > c){
//			return a;
//		}
//		return c;
//	}
//	return b;
//}
//
//int main() {
//	
//	freopen("file.inp","r",stdin);
//	freopen("file.uot","w",stdout);
//	
//	int a,b,c;
//	scanf("%d %d %d", &a, &b, &c);
//	printf("%d la so lon nhat",CheckNumber(a,b,c));
//	
//	return 0;
//}



