#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;


int main() {
	freopen("IntNumberFile.inp", "r", stdin);
	freopen("OutputFile.out", "w", stdout);
	
	int a, b, c, d;
	
	scanf("%d %d %d %d", &a, &b, &c, &d);
	
	printf("%d, %d, %d, %d\n", a, b, c, d);
	
	
	return 0;
}
