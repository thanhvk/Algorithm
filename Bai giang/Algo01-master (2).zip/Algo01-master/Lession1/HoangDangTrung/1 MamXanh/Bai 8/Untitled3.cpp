#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	int a;
	
	scanf("%d", &a);
	
	printf("a^2 = %d\n", a*a);
	printf("a^3 = %d\n", a*a*a);
	
	
	return 0;
}
