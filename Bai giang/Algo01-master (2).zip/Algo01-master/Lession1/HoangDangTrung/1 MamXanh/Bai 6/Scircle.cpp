#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	int r;
	scanf("%d", &r);
	
	printf("S circle = %f", 3.14*r*r);
	
	
	return 0;
}
