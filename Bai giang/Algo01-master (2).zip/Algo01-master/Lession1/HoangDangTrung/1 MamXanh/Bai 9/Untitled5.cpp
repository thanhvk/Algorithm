#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	while(1){
	
	int s;
	scanf("%d", &s);
	
	int hour, minute, second;
//	h*3600 + minute*60 + second = s
	second = s % 60;
	minute = s / 60;
	hour = minute / 60;
	minute = minute % 60;
	
	printf("Time: %02d:%02d:%02d\n", hour, minute, second);
	
//	return 0;
}
}
