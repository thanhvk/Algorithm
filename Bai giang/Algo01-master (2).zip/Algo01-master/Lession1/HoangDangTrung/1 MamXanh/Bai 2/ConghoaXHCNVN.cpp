#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;


int main() {
	printf("Hello World\n");
	printf("Cong hoa xa hoi chu nghia Viet Nam\n");
	printf("Doc lap * Tu do * Hanh phuc\n");
	
	return 0;
}








