#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	int r;
	
	scanf("%d", &r);
	
	printf("Sglobular = %f\n", 4*3.14*r*r);
	printf("Vglobular = %f\n", (4/3)*3.14*r*r*r);
	
	
	return 0;
}
