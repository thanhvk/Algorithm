#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
		
		freopen("File.txt", "r", stdin);
		
		int a;
		scanf("%d", &a);
		
		if (a<0) {
			printf("%d is negative number", a);
		} else {
			if (a%2==0) {
				printf("%d is even number", a);
			} else {
				printf("%d is odd number", a);
			}
		}		
		

		
		
		
		
	return 0;
}
