#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	while(1) {
	int a, b;
	scanf("%d %d", &a, &b);
	
	
	if(a>b) {
		printf("Max = %d\n", a);
	} else {
		printf("Max = %d\n", b);
	}
	
}
//	return 0;
}
