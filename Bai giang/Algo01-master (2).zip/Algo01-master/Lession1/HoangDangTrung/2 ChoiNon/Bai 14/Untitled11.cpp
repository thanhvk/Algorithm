#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	while(1) {
	int a, b, c;
	scanf("%d %d %d", &a, &b, &c);
	
	
	if(a >= b && a >= c) {
		printf("Max = %d", a);
	} else if (b >= a && b >= c) {
		printf("Max = %d", b);
	} else {
		printf("Max = %d", c);
	}
	
}
//	return 0;
}
