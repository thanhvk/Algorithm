#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	while(1) {
	int a, b;
	scanf("%d %d", &a, &b);
	
	
	if(a == b) {
		printf("%d equal %d\n", a, b);
	} else {
		printf("%d not equal %d\n", a, b);
	}
	
}
//	return 0;
}
