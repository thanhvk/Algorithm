#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	while(1) {
	float a;
	scanf("%f", &a);
	
	
	if(a >= 9) {
		printf("Xuat sac");
	} else if (a >= 8) {
		printf("Gioi");
	} else if (a >= 7) {
		printf("Kha");
	} else if (a >= 6) {
		printf("Trung Binh");
	} else {
		printf("Yeu");
	}
	
}
//	return 0;
}
