#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	
	freopen("file.txt", "r", stdin);
	int a, b;
	scanf("%d %d %d", &a, &b);
	
	if(a > 40) {
		printf("Tong luong = %d", 40*b + (a-40)*2*b);
	} else {
		printf("Tong luong = %d", a*b);
	}

//	return 0;
}
