#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

// aX^2 + bX + c = 0

int main() {
	while(1) {
		
		int a, b, c;
		scanf("%d %d %d", &a, &b, &c);
		
		if (a==0) {
			printf("a != 0, please!");
		} else {
			float delta, x1, x2;
			delta = b*b - 4*a*c;
			if (delta < 0) {
				printf("Phuong trinh vo nghiem!\n");
			} else if (delta==0) {
				x1 = -b/(2*(float)a);
				printf("Phuong trinh co nghiem kep x1 = x2 = %f", x1);
			} else {
				x1 = (-b + sqrt(delta))/(2*(float)a);
				x2 = (-b - sqrt(delta))/(2*(float)a);
				
				printf("Phuong trinh co 2 nghiem phan biet: \n x1 = %f \n x2 = %f\n", x1, x2);
			}
		}

		
		
		
		
	}
//	return 0;
}
