#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	
	int a, b, c;
	scanf("%d %d %d", &a, &b, &c);
	
	
	if(a+b>c && a+c>b && b+c>a) {
		float p, S;
		
		p = (a+b+c)/2;
		
		S = sqrt(p*(p-a)*(p-b)*(p-c));
		
		printf("S triangle = %f\n", S);
		
	} else {
		printf("Triangle not exist\n");
	}

//	return 0;
}
