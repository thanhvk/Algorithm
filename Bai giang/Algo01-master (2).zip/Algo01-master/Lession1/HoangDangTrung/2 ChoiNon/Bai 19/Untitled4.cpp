#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
		freopen("File.txt", "r", stdin);
		int a;
		scanf("%d", &a);
		
		float bill;
		
		if(a<=50) {
			bill = a*230;
		} else {
			if (a<=100) {
				bill = 50*230 + (a%50)*480;
			} else {
				if (a<150) {
					bill = 50*230 + 50*480 + (a%100)*700;
				} else {
					bill = 50*230 + 50*480 + 50*700 + (a%150)*900;
				}
			}
		}
		
		printf("Bill = %.f VND", bill + 1000);
		
		
		
		
	
//	return 0;
}
