#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;
// ax + b = 0

int main() {
	while(1) {
		
		int a, b;
		scanf("%d %d", &a, &b);
		
		float x;
		
		if (a==0) {
			if (b==0) {
				printf("Phuong trinh co vo so nghiem\n");
			} else {
				printf("Phuong trinh vo nghiem\n");
			}
		} else {
			x = -b/(float)a;
			printf("x = %f\n", x);
		}
				

		
		
		
		
	}
//	return 0;
}
