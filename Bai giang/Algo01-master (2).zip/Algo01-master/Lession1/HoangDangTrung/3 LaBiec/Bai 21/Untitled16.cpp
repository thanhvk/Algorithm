#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	printf("So luong number trong day: ");
	int N, a, Min, f = 1; 
	scanf("%d\n", &N);
	
	scanf("%d\n", &a);
	
	Min = a;
	
	for(int i=1; i<N; i++) {
		int b;
		scanf("%d", &b);
		if (b == Min) {
			f = f + 1;
		}
		if (b<Min) {
			Min = b;
			f = 1;
		}
	}
	
	printf("Min = %d  frequency: %d", Min, f);

		
		

		
		
		
		

//	return 0;
}
