#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	while(1) {
		
		int a=0, sum=0;
		scanf("%d", &a);
		
		while(a/10 > 0) {
			sum = sum + a%10;
			a = a/10;
		}
		sum = sum + a;

		printf("Tong cac chu so = %d\n", sum);
		
		
		
	}
//	return 0;
}
