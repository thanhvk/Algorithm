#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
		
		freopen("File.txt", "r", stdin);
		int a;
		
		for (int i=0; i<100; i++) {
			scanf("%d", &a);
			if(a%10 != 0) {
				printf("%d\n", a);
			} else {
				i = 100;
			}
		}
		
		
	
		
	
//	return 0;
}
