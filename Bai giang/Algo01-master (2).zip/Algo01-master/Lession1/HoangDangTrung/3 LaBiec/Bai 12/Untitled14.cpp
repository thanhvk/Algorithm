#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

bool isCheckPrimeNumber(int n) {
	if(n<2) {
		return false;
	} 
	if(n==2) {
		return true;
	}
	for(int i=2; i<=sqrt(n); i++) {
		if(n%i==0) {
			return false;
		} 
	}
	return true;
}

int main() {
	while(1) {
		
		int a;
		
		while(1) {
			scanf("%d", &a);
			if(isCheckPrimeNumber(a)) {
				printf("%d la so nguyen to\n", a);
			} else {
				printf("%d khong la so nguyen to\n", a);
			}
		}
		
	}
//	return 0;
}
