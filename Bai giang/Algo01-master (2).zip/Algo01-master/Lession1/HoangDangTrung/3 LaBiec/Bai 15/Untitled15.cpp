#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

void doPrint(int n, char symbol) {
		for(int i=0; i<n; i++) {
			printf("%c",symbol);
		}
	}
	
int main() {
	
	while(1) {
		
		int a;
		scanf("%d", &a);
		
		for(int i=0; i<a; i++) {
			if (i==0 || i==a-1) {
				doPrint(a-i-1, ' ');
				doPrint(2*i+1, '*');
				doPrint(a-i-1, ' ');
				printf("\n");
			} else {
				doPrint(a-i-1, ' ');
				printf("*");
				doPrint(2*i-1, ' ');
				printf("*");
				doPrint(a-i-1, ' ');
				printf("\n");
			}
			
		}

		
		
		
		
	}
//	return 0;
}
