#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main() {
	while(1) {
		
		int a, sumOfOdd = 0;
		scanf("%d", &a);
		
		for (int i=1; i<=a; i++) {
			if(i%2==1) {
				sumOfOdd = sumOfOdd + i;
			}
		}

		printf("Tong cac so le = %d\n", sumOfOdd);
		
		
		
	}
//	return 0;
}
