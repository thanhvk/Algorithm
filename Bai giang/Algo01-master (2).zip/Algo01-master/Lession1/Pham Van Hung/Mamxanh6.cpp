#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

using namespace std;

int main(){
	float r, pi=3.14;
	cout<<"Nhap ban kinh cua hinh tron"<<endl;
	cin>>r;
	cout<<"Dien tich cua hinh tron la: "<<pi*r*r;
	return 0;
}
