#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

bool SNT(int x){
	if(x<2) return false;
	else{
		for(int i=2;i<=sqrt(x);i++){
			if(x%i==0) return false;
		}
	}
	return true;
}
int main(){
	int n,x;
	cin>>n;
	while(n>0){
		cin>>x;
		if(SNT(x)) cout<<x<<" la so nguyen to";
		else cout<<x<<" ko phai la so nguyen to";
	}
	return 0;
}

