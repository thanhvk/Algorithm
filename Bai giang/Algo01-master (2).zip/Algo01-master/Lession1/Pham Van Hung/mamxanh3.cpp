#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

int main(){
	ifstream f("mamxanh3.txt",ios::in);
	int x;
	f>>x;
	cout<<"So o trong file la: "<<x;
	return 0;
}

