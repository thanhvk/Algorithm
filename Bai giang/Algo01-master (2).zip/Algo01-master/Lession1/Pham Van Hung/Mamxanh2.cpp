#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

using namespace std;

int main(){
	cout<<"Hello word "<<endl;
	cout<<"Cong hoa xa hoi chu nghia Viet Nam"<<endl;
	cout<<"Doc lap*Tu do*Hanh phuc";
	return 0;
}
