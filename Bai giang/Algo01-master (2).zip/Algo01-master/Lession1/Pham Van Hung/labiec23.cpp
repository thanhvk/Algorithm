#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

int main(){
	int x,s=0;
	cin>>x;
	while(x!=0){
		s+=x%10;
		x=x/10;
	}
	cout<<s;
	return 0;
}

