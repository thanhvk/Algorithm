#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

int main(){
	int a,b;
	cin>>a>>b;
	for(int i=0;i<b;i++){
		for(int j=0;j<a;j++){
			if(i==0||i==b-1||j==0||j==a-1) cout<<"*";
			else{
				cout<<" ";
			}
		}
		cout<<endl;
	}
}
