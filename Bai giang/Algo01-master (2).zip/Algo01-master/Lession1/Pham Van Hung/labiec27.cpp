#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

void DoPrint(int Num, char kytu){
	for(int i=0;i<Num;i++){
		cout<<kytu;
	}
}

int main(){
	int a,b;
	cin>>a;
	cin>>b;
	while(b%2==0){
		cin>>b;
	}
	DoPrint(b,'*');
	cout<<endl;
	for(int i=0;i<a-1;i++){
		DoPrint(b/2,' ');
		DoPrint(1,'*');
		DoPrint(b/2,' ');
		cout<<endl;
	}
	return 0;
}

