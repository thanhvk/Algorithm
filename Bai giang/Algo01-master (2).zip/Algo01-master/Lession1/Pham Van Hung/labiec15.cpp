#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

void DoPrint(int Num,char kytu){
	for(int i=0;i<Num;i++){
		cout<<kytu;
	}
}

int main(){
	int h;
	cin>>h;
	DoPrint(h-1,' ');
	DoPrint(1,'*');
	DoPrint(h-1,' ');
	cout<<endl;
	int a=2,b=1;
	for(int i=0;i<h-2;i++){
		DoPrint(h-a,' ');
		DoPrint(1,'*');
		DoPrint(b,' ');
		DoPrint(1,'*');
		a++;b+=2;
		cout<<endl;
	}
	DoPrint(2*h-1,'*');
	return 0;
}

