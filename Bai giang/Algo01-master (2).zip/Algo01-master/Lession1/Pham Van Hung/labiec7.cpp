#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

void DoPrint(int Num,char kytu){
	for(int i=0;i<Num;i++){
		cout<<kytu;
	}
}

int main(){
	int h;
	cin>>h;
	int a=1,b=1;
	for(int i=1;i<=h;i++){
		DoPrint(h-a,' ');
		DoPrint(b,'*');
		DoPrint(h/2-b,' ');
		a++;b+=2;
		cout<<endl;
	}
	return 0;
}

