#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

int main(){
	int n,x,b,d,min;
	cin>>n;
	while(n>0){
		d=1;
		cin>>x;
		cin>>min;
		for(int i=0;i<x-1;i++){
			cin>>b;
			if(b==min) d++;
			if(b<min){
				min=b;
				d=1;
			}
			}
		cout<<min<<"  "<<d;
		x=0;
		n--;
	}
	return 0;
}

