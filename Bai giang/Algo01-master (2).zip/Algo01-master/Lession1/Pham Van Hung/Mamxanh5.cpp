#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

using namespace std;

int main(){
	int a,b;
	cout<<"Nhap 2 so nguyen bat ki"<<endl;
	cin>>a>>b;
	cout<<"Tong 2 so do la: "<<a+b;
	return 0;
}
