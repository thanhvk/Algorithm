#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>

using namespace std;

void DoPrint(int Num, char kytu){
	for(int i=0;i<Num;i++){
		cout<<kytu;
	}
}

int main(){
	int h;
	cin>>h;
	while(h%2==0){
		cin>>h;
	}
	int a=1,b=2,c=1,d=h/2;
	for(int i=0;i<h/2;i++){
		DoPrint(a,'*');
		DoPrint(h-b,' ');
		DoPrint(c,'*');
		DoPrint(d,' ');
		a++;b+=2;c+=2;d--;
		cout<<endl;
	}
	DoPrint(h+h/2,'*');
	cout<<endl;
	a--;b-=2;c-=2;d++;
	for(int i=0;i<h/2;i++){
		DoPrint(a,'*');
		DoPrint(h-b,' ');
		DoPrint(c,'*');
		DoPrint(d,' ');
		cout<<endl;
		a--;b-=2;c-=2;d++;
	}
	return 0;
}

