#include<iostream>
#include<fstream>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

using namespace std;

int main(){
	int h,p,s,x;
	cout<<"Nhap so gio phut giay hien tai"<<endl;
	cin>>h>>p>>s;
	cout<<"Nhap so giay troi ";
	cin>>x;
	s+=x+h*3600+p*60;
	h=s/3600;
	s=s-h*3600;
	p=s/60;
	s=s-p*60;
	if(h==24) h=0;
	cout<<h<<":"<<p<<":"<<s;
}
