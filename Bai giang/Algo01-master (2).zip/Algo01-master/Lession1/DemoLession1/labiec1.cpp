#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;


int main()
{
	freopen("labiec1.inp","r",stdin);
	freopen("labiec1.out","w",stdout);
	
	int a;
	scanf("%d",&a);
	
	for(int i =0;i< a; i++){
		printf("Vi du su dung vong lap for\n");
	}
	

	return 0;
}




	

