#include<stdio.h>
#include<conio.h>
#include<iostream>
#include<fstream>
#include<string.h>

int main(){
	freopen("mamxanh3.inp","r",stdin);
	freopen("mamxanh3.out","w",stdout);
	
	int a,b;
	scanf("%d %d",&a,&b);
	
	printf("So o file la: %d\n",a);
	
	return 0;
}
