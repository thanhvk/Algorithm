#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
	freopen("mamxanh5.inp","r",stdin);
	freopen("mamxanh5.out","w",stdout);
	
	int a,b;
	scanf("%d %d",&a,&b);
	
	printf("Tong 2 so la: %d\n",a+b);
	
	return 0;
}

