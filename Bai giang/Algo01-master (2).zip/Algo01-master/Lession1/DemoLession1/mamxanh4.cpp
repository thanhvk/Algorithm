#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

int main()
{
	freopen("mamxanh4.inp","r",stdin);
	freopen("mamxanh4.out","w",stdout);
	
	int a,b;
	scanf("%d %d",&a,&b);
	
	printf("So thu nhat o file la: %d\n",a);
	printf("So thu hai o file la: %d\n",b);
	
	
	return 0;
}

