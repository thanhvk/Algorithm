//
//  main.cpp
//  Labiec35
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int h, w, d;
    scanf("%d %d %d", &h, &w, &d);
    
    for (int i=1; i<=h-1; i++) {
        for (int j=1; j<=d; j++) {
            doPrint(1, '*');
            doPrint(d-1, ' ');
        }
        doPrint(1, '*');
        printf("\n");
    }
    doPrint(w, '*');
    printf("\n");
    return 0;
}
