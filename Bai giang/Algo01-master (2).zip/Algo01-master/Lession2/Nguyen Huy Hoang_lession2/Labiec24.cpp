//
//  main.cpp
//  Labiec24
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    for (int i=1; i<=10; i++) {
        for (int j=1; j<=10; j++) {
            printf("%4d", i*j);
        }
        printf("\n");
    }
    return 0;
}
