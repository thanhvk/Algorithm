//
//  main.cpp
//  Labiec29
//
//  Created by anhhoangta on 3/21/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, int kitu){
    for (int i=0; i<num; i++){
        if (kitu == 0) {
            printf(" ");
        }else
            printf("%d", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n, x;
    scanf("%d %d", &n, &x);
    for (int i =0; i<n; i++) {
        doPrint(i, 0);
        doPrint(2*n-2*i-1, x*i+1);
        doPrint(i, 0);
        printf("\n");
    }
    
    return 0;
}
