//
//  main.cpp
//  Labiec34
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int h, w, d;
    bool isPrint = false;
    scanf("%d %d %d", &h, &w, &d);
    
    for (int i=1; i<=h; i++) {
        for (int j=0; j<=i; j++) {
            if (i == 2+j*d) {
                doPrint(w, '*');
                printf("\n");
                isPrint = true;
                break;
            }
        }
        if (!isPrint) {
            doPrint(1, '*');
            doPrint(w-2, ' ');
            doPrint(1, '*');
            printf("\n");
        }else
            isPrint = false;
    }
    return 0;
}
