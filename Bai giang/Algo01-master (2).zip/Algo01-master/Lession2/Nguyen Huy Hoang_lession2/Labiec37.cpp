//
//  main.cpp
//  Labiec37
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n, w;
    scanf("%d %d", &n, &w);
    
    for (int i=1; i<=n; i++) {
        
        for (int j=1; j<=w/2; j++) {
            if (j==1) {
                doPrint(w/2, ' ');
                doPrint(1, '*');
                doPrint(w/2, ' ');
                printf("\n");
            }else {
                doPrint(w/2-j+1, ' ');
                doPrint(1, '*');
                doPrint(2*j-3, ' ');
                doPrint(1, '*');
                doPrint(w/2-j+1, ' ');
                printf("\n");
            }
        }
        doPrint(1, '*');
        doPrint(w-2, ' ');
        doPrint(1, '*');
        printf("\n");
        
        for (int k=1; k<w/2; k++) {
            doPrint(k, ' ');
            doPrint(1, '*');
            doPrint(2*(w/2-k)-1, ' ');
            doPrint(1, '*');
            doPrint(k, ' ');
            printf("\n");
            }
        }
    doPrint(w/2, ' ');
    doPrint(1, '*');
    doPrint(w/2, ' ');
    printf("\n");
    return 0;

    }

