//
//  main.cpp
//  Labiec28
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n;
    scanf("%d", &n);
    for (int i =0; i<n; i++) {
        doPrint(i, ' ');
        doPrint(2*n-2*i-1, '*');
        doPrint(i, ' ');
        printf("\n");
    }
    return 0;
}
