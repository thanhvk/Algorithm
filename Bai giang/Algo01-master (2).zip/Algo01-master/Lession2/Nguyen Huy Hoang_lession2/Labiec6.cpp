//
//  main.cpp
//  Labiec6
//
//  Created by anhhoangta on 3/19/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int n;
    scanf("%d", &n);
    
    for (int i=1; i <= n/2; i++) {
        if (n%i == 0) {
            printf("%d ", i);
        }
    }
    return 0;
}
