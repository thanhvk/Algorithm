//
//  main.cpp
//  Labiec32
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, int kitu){
    for (int i=0; i<num; i++){
        if (kitu == 0) {
            printf(" ");
        }else
            printf("%d", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n;
    scanf("%d", &n);
    for (int i=n; i>n/2+1; i--) {
        doPrint(n-i, 0);
        doPrint(1, i);
        doPrint(2*i-n-2, 0);
        doPrint(1, i);
        doPrint(n-i, 0);
        printf("\n");
    }
    doPrint(n/2, 0);
    doPrint(1, n/2+1);
    doPrint(n/2, 0);
    printf("\n");
    for (int j=n/2; j>=1; j--) {
        doPrint(j-1, 0);
        doPrint(1, j);
        doPrint(n-2*j, 0);
        doPrint(1, j);
        doPrint(j-1, 0);
        printf("\n");
        
    }
}