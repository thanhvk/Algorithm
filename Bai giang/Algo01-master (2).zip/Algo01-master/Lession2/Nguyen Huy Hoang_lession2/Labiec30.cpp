//
//  main.cpp
//  Labiec30
//
//  Created by anhhoangta on 3/19/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>
void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

//int main(int argc, const char * argv[]) {
//    int n;
//    scanf("%d", &n);
//    for (int i=1; i<=n; i++) {
//        for (int j=1; j<=n; j++) {
//            if (j == i || j== n - i +1) {
//                printf("*");
//            }else
//                printf(" ");
//        }
//        printf("\n");
//    }
//    return 0;
//}

int main(int argc, const char * argv[]) {
    int n;
    scanf("%d", &n);
    for (int i=1; i<=n/2; i++) {
        doPrint(i-1, ' ');
        doPrint(1, '*');
        doPrint(n-2*i, ' ');
        doPrint(1, '*');
        doPrint(i-1, ' ');
        printf("\n");
    }
    doPrint(n/2, ' ');
    doPrint(1, '*');
    doPrint(n/2, ' ');
    printf("\n");
    for (int j=n/2; j>=1; j--) {
        doPrint(j-1, ' ');
        doPrint(1, '*');
        doPrint(n-2*j, ' ');
        doPrint(1, '*');
        doPrint(j-1, ' ');
        printf("\n");
        
    }
}