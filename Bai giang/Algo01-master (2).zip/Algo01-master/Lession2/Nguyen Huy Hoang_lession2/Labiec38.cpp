//
//  main.cpp
//  Labiec38
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, int kitu){
    for (int i=0; i<num; i++){
        if (kitu==-1) {
            printf(" ");
        }else
            printf("%d", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n, w;
    scanf("%d %d", &n, &w);
    
    for (int i=1; i<=n; i++) {
        for (int j=1; j<w; j++) {
            if (j==1) {
                for (int k=0; k<w; k++) {
                    doPrint(1, (k+(w-1)*2*(i-1))%10);
                }
                printf("\n");
            }else {
                doPrint(w-j, -1);
                doPrint(1, ((w-1)*(2*i-1)+j-1)%10);
                doPrint(j-1, -1);
                printf("\n");
            }
        }
    }
    for (int l=1; l<=w; l++) {
        doPrint(1, (l+w-2 +((w-1)*2*(n-1)+w-1))%10);
    }
    printf("\n");
    return 0;
}
