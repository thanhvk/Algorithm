//
//  main.cpp
//  Labiec10
//
//  Created by anhhoangta on 3/19/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int UCLN(int a, int b){
    int temp;
    if (a >b) {
        temp = a;
        a = b;
        b = temp;
    }
    int r = a%b;
    while (r != 0) {
        a = b;
        b = r;
        r = a%b;
    }
    return b;
}

int main(int argc, const char * argv[]) {
    int a, b;
    scanf("%d %d", &a, &b);
    printf("%d\n", UCLN(a, b));
    printf("%d\n", a*b/(UCLN(a, b)));
    return 0;
}
