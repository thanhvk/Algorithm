//
//  main.cpp
//  Labiec40
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n, w;
    scanf("%d %d", &n, &w);
    
    for (int i=1; i<=w; i++) {
        for (int j=1; j<=n; j++) {
            if (i==1 || i==w) {
                doPrint(w/2, ' ');
                doPrint(1, '*');
                doPrint(w/2-1, ' ');
            } else if (i<=w/2){
                doPrint(w/2+1-i, ' ');
                doPrint(1, '*');
                doPrint(2*(i-1)-1, ' ');
                doPrint(1, '*');
                doPrint(w/2-i, ' ');
            } else if (i==w/2+1){
                doPrint(1, '*');
                doPrint(w-2, ' ');
                if (j==n) {
                    doPrint(1, '*');
                }
            } else if (i<w){
                doPrint(i-w/2-1, ' ');
                doPrint(1, '*');
                doPrint(2*w-2*i-1, ' ');
                doPrint(1, '*');
                doPrint(i-w/2-2, ' ');
            }
                
        
        }
        printf("\n");
    }
    return 0;
    
}

