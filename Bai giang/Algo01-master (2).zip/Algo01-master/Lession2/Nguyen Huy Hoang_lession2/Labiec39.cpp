//
//  main.cpp
//  Labiec39
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n, h;
    scanf("%d %d", &n, &h);
    
    for (int i=1; i<=h; i++) {
        for (int j=1; j<=n; j++) {
            if (i==1) {
                doPrint(1, '*');
                doPrint(2*h-3, ' ');
                if (j==n) {
                    doPrint(1, '*');
                }
                
            }else if (i<h){
                doPrint(i-1, ' ');
                doPrint(1, '*');
                doPrint(2*h-2*i-1, ' ');
                doPrint(1, '*');
                doPrint(i-2, ' ');
                
                
            }else {
                doPrint((2*h-1)/2, ' ');
                doPrint(1, '*');
                doPrint((2*h-1)/2-1, ' ');
            }
            
            
        }
        printf("\n");
    }
    
    return 0;
}
