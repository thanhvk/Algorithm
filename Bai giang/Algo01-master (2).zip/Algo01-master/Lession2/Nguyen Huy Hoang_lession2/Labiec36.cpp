//
//  main.cpp
//  Labiec36
//
//  Created by anhhoangta on 3/20/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

void doPrint(int num, char kitu){
    for (int i=0; i<num; i++){
        printf("%c", kitu);
    }
}

int main(int argc, const char * argv[]) {
    int n, w;
    scanf("%d %d", &n, &w);
    
    for (int i=1; i<=n; i++) {
        for (int j=1; j<w; j++) {
            if (j==1) {
                doPrint(w, '*');
                printf("\n");
            }else {
                doPrint(w-j, ' ');
                doPrint(1, '*');
                doPrint(j-1, ' ');
                printf("\n");
            }
        }
    }
    doPrint(w, '*');
    printf("\n");
    return 0;
}
