//
//  main.cpp
//  Labiec16
//
//  Created by anhhoangta on 3/19/16.
//  Copyright © 2016 anhhoangta. All rights reserved.
//

#include <iostream>

int factorial(int n){
    int result = 1;
    if (n == 0) {
        return 1;
    }else {
        for (int i=1; i<=n; i++) {
            result = result * i;
        }
    }
    return result;
}

int main(int argc, const char * argv[]) {
    int n, x;
    scanf("%d", &n);
    for (int i=1; i<=n; i++) {
        scanf("%d", &x);
        printf("%d! = %d\n", x, factorial(x));
    }
    return 0;
}
