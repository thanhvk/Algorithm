#include <conio.h>
#include <stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int dem = 0;
	for(int i = n-1; i > 0 ; i--)
	{
		int j = n -i;
		if(i > j)
		{
			dem++;	
		}
	}
	printf("%d\n",dem);
	for(int i = n -1; i > 0 ; i--)
	{
		int j = n -i;
		if(i > j)
		{
			printf("%d %d\n", i,j);
		}
	}
	getch();
	return 0;
}
