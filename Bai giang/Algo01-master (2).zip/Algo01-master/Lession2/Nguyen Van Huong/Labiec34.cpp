#include <conio.h>
#include <stdio.h>
void DoPrintf(int n, char kitu)
{
	for(int i = 0; i < n; i++)
	{
		printf("%c",kitu);
	}
}
int main()
{
	printf("Nhap chieu cao, rong, khoang cach : ");
	int Cao, Rong, Khoang;
	scanf("%d %d %d", &Cao, &Rong, &Khoang);
	
	for(int i = 1; i <= Cao; i++)
	{
		if(i == 2 || (i-2) % Khoang == 0)
		{
			DoPrintf(Rong,'*');
			printf("\n");
		}
		else
		{
			DoPrintf(1,'*');
			DoPrintf(Rong - 2,' ');
			DoPrintf(1, '*');
			printf("\n");
		}	
	}
	
	
	getch();
	return 0;
}
