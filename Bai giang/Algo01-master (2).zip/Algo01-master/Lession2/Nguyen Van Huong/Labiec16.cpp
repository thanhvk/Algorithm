#include <conio.h>
#include <stdio.h>
int GiaiThua(int x)
{
	int tong = 1;
	for(int i = 1; i <= x; i++)
	{
		tong = tong * i;
	}
	return tong;
}
int main()
{
	int a;
	scanf("%d", &a);

	for(int i = 0; i < a; i++)
	{
		
		int n;
		do
		{
			scanf("%d", &n);
			if(n < 0 || n > 7)
			{
				printf("Nhap lai \n");
			}
		}while(n < 0 || n > 7);
		int x = GiaiThua(n);
		printf("%d! = %d \n", n,x);
	}
	
	
	getch();
	return 0;
}
