#include <conio.h>
#include <stdio.h>
void DoPrintf(int n, char kitu)
{
	for(int i = 0; i < n; i++)
	{
		printf("%c",kitu);
	}
}
void DoPrintfNumber(int n, int m)
{
	for(int i = 0; i < n; i++)
	{
		printf("%d",m);
	}
}
int main()
{
	freopen("Labiec29.txt","r",stdin);
	// n la so dong, m la so cong
	int n, m;
	scanf("%d %d", &n, &m);
	int dem = 1;
	int dem2 = 2*n -1;
	for(int i = 1; i <= n;i++)
	{
		DoPrintf(i -1,' ');
		DoPrintfNumber(dem2,dem);
		dem2 -= 2;
		dem += m;
		printf("\n");
	}
	
	getch();
	return 0;
}
