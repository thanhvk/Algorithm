#include <conio.h>
#include <stdio.h>
void DoPrintf(int n, char kitu)
{
	for(int i = 0; i < n; i++)
	{
		printf("%c",kitu);
	}
}

int main()
{
	int n;
	scanf("%d", &n);
	int dem = n - 2;
	for(int i = 1; i<= n / 2;i++)
	{
		DoPrintf(i,'*');
		
		DoPrintf(dem,' ');
		dem = dem - 2;
		DoPrintf(i,'*');
		printf("\n");
	}
	
	DoPrintf(n,'*');
	printf("\n");
	int dem2 = 1;
	for(int i = n / 2; i >= 1; i--)
	{
		DoPrintf(i,'*');
		DoPrintf(dem2,' ');
		dem2 = dem2 + 2;
		DoPrintf(i,'*');
		printf("\n");
	}
	
	getch();
	return 0;
}
