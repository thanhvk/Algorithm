#include <conio.h>
#include <stdio.h>

int main()
{
	for(int i = 1; i <= 9; i++)
	{
		for(int j = 1; j <= 9; j++)
		{
			printf("%d  x %2d  =  %2d",i,j,i*j);
			printf("\n");
		}
		printf("\n");
	}
	getch();
	return 0;
}
