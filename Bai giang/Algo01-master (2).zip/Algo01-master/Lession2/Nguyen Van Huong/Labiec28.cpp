#include <conio.h>
#include <stdio.h>
void DoPrintf(int n, char kitu)
{
	for(int i = 0; i < n; i++)
	{
		printf("%c",kitu);
	}
}
int main()
{
	int n;
	scanf("%d", &n);
	int dem = 2*n-1;
	for(int i = 1; i<= n; i++)
	{
		DoPrintf(i - 1,' ');
		DoPrintf(dem, '*');
		dem = dem - 2;
		printf("\n");
	}
	
	getch();
	return 0;
}
