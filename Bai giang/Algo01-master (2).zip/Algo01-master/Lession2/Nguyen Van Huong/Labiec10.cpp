#include <conio.h>
#include <stdio.h>

int TimUCLN(int a, int b)
{
	
	int Max = a > b ? a : b;
	int Min = a < b ? a : b;
	if(Max % Min == 0)
	{
		return Min;
	}
	int r = Max % Min;
	while(r != 0)
	{
		r = Max % Min;
		Max = Min;
		Min = r;
	}
	return Max;
}
int TimBCNN(int a, int b)
{
	return a*b / TimUCLN(a,b);
}
int main()
{
	int a, b;
	do
	{
		scanf("%d %d", &a,&b);
		if(a > 100 || b > 100)
		{
			printf("\nNhap lai !\n");
		}
	}while(a > 100 || b > 100);
	
	int x = TimUCLN(a,b);
	int y = TimBCNN(a,b);
	
	printf("%d \n%d",x,y);
	
	getch();
	return 0;
}
