//
//  main.cpp
//  labiec40
//
//  Created by Quang Huy on 3/21/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
bool check(int n, int h){
    if (n <= 0 || h <= 1 || h%2 == 0) {
        return false;
    }
    return true;
}
void printHinhThoi(int n, int h){
    int middlePoint = (h-1)/2;
    for (int i = 0; i < h; i++) {
        int k;
        for (int j = 0; j < n * (h - 1) + 1; j ++) {
            k = j /(h-1) + 1;
            int m = (k-1)*(h-1);
            if ( i <= (h - 1)/2) {
                if ( j - m + i == middlePoint || j - i == middlePoint + m) {
                    printf("*");
                }else{
                    printf(" ");
                }
            }else{
                if (i - j  == middlePoint - m || j == 3*middlePoint - i + m) {
                    printf("*");
                }else{
                    printf(" ");
                }
            }
        }
        printf("\n");
        
    }
}
int main(int argc, const char * argv[]) {
    int n, h;
    printf("Nhap chieu cao:\n");
    scanf("%d", &h);
    printf("Nhap so hinh thoi:\n");
    scanf("%d", &n);
    printf("\n");
    bool isOK = check(n, h);
    if (isOK) {
        printHinhThoi(n, h);
    }else{
        printf("Chieu cao hoac so chu can ve khong thoa man\n");
    }

    return 0;
}
