//
//  main.cpp
//  labiec28
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void printTamGiacNguoc(int h){
    if (h > 1) {
        for (int i = 0; i < h ; i ++) {
            for (int j = 0; j < h * 2 - 1; j ++) {
                if ( j >= i && j < h * 2 - 1 - i) {
                    printf("*");
                }else{
                    printf(" ");
                }
            }
            printf("\n");
        }
    }else{
        printf("Chieu cao tam giac phai lon hon 1\n");
    }
}
int main(int argc, const char * argv[]) {
    printf("Nhap vao chieu cao tam giac:\n");
    int h;
    scanf("%d", &h);
    printTamGiacNguoc(h);
    return 0;
}
