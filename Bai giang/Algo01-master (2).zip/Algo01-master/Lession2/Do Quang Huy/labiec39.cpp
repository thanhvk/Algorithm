//
//  main.cpp
//  labiec39
//
//  Created by Quang Huy on 3/21/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
bool check(int n, int h){
    if (n <= 0 || h <= 1) {
        return false;
    }
    return true;
}
void printV(int n, int h){
    for (int i = 0; i < h; i ++) {
        int k;
        for (int j = 0; j < 2*n*(h-1) + 1; j++) {
            k = j /(2*(h-1)) + 1;
            int m = 2 * (h-1);
            if (j - m*(k - 1) == i || j ==  m*k - i) {
                printf("*");
            }else{
                printf(" ");
            }
        }
        printf("\n");
    }
}
int main(int argc, const char * argv[]) {
    int n, h;
    printf("Nhap chieu cao:\n");
    scanf("%d", &h);
    printf("Nhap so chu V:\n");
    scanf("%d", &n);
    printf("\n");
    bool isOK = check(n, h);
    if (isOK) {
        printV(n, h);
    }else{
        printf("Chieu cao hoac so chu can ve khong thoa man\n");
    }
    return 0;
}
