//
//  main.cpp
//  labiec34
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
//Viết chương trình vẽ một cái thang bằng các dấu ‘*” với chiều cao và rộng nhập và khoảng cách giữa các thanh ngang nhập từ file (chiều rộng lớn hơn 2 và hai số còn lại đều lớn hơn 1). Biết rằng bậc thang cao nhất luôn có thứ tự thứ 2 từ trên xuống và bậc thang cuối cùng phải nằm trong phạm vi thang
bool checkSuPhuHopGiuaChieuCaoVaChieuRongVaKhoangCach(int h, int w, int d){
    if (w <= 2 || h <= 1 || d <= 1) {
        return false;
    }
    return true;
}
void printThang(int h, int w, int d){
    int start = 1;
    bool isMatch = false;
        for (int i = 0; i < h; i ++) {
            for (int j = 0; j < w; j ++) {
                if (i == start || j == 0 || j == w - 1){
                    printf("*");
                    if (i == start) {
                        isMatch = true;
                    }
                }else{
                    printf(" ");
                }
            }
            if (isMatch) {
                start += d;
                isMatch = false;
            }
            printf("\n");
        }
}
int main(int argc, const char * argv[]) {
    printf("Nhap chieu cao:\n");
    int h;
    scanf("%d", &h);
    printf("Nhap chieu rong:\n");
    int w;
    scanf("%d", &w);
    printf("Nhap khoang cach:\n");
    int d;
    scanf("%d", &d);
    printf("\n");
    bool isOK = checkSuPhuHopGiuaChieuCaoVaChieuRongVaKhoangCach(h, w, d);
    if (isOK) {
        printThang(h, w, d);
    }else{
        printf("Thong so nhap vao khong thoa man\n");
    }
    return 0;
}
