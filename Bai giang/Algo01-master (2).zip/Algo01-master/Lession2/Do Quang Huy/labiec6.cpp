//
//  main.cpp
//  labiec6
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
//Viết chương trình nhập vào một số nguyên lớn hơn 1 rồi in ra tất cả các ước số của số đó
void printFactors(int n){
    printf("Uoc so cua %d:\n", n);
    for (int i = 1; i < n; i++) {
        if (n%i == 0) {
            printf("%d\n", i);
        }
    }
    
    printf("%d\n", n);
    
}

int main(int argc, const char * argv[]) {
    int n;
    printf("Nhap 1 so:\n");
    scanf("%d", &n);
    printFactors(n);
    return 0;
}
