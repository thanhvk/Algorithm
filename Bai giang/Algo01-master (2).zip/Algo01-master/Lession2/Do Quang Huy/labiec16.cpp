//
//  main.cpp
//  labiec16
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void printGiaiThua(int n){
    if (n >= 0) {
        int giaiThua = 1;
        for (int i = 1; i<= n; i++) {
            giaiThua *= i;
        }
        printf("%d! = %d\n",n, giaiThua);

    }else{
        printf("Moi nhap 1 lai 1 so nguyen duong\n");
    }
}
int main(int argc, const char * argv[]) {
    printf("Nhap so lan test:\n");
    int nTest;
    scanf("%d", &nTest);
    for (int i = 0; i < nTest; i ++) {
        printf("Nhap vao 1 so:\n");
        int n;
        scanf("%d", &n);
        printGiaiThua(n);
    }
        return 0;
}
