//
//  main.cpp
//  labiec29
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
bool checkChieuCaoVaCongSai(int h, int x){
    if (h <= 1 && x <= 0) {
        return false;
    }
    int sum = 1;
    for (int i = 1; i < h; i ++) {
        sum += x;
    }
    if (sum > 9) {
        return false;
    }
    return true;
}
void printTamGiacSoNguoc(int h, int x){
    int number = 1;
    for (int i = 0; i < h ; i ++) {
        for (int j = 0; j < h * 2 - 1; j ++) {
            if ( j >= i && j < h * 2 - 1 - i) {
                printf("%d", number);
            }else{
                printf(" ");
            }
        }
        number += x;
        printf("\n");
    }
}
int main(int argc, const char * argv[]) {
    printf("Nhap chieu cao:\n");
    int h;
    scanf("%d", &h);
    printf("Nhap cong sai:\n");
    int x;
    scanf("%d", &x);
    printf("\n");

    bool isOK = checkChieuCaoVaCongSai(h, x);
    if (isOK) {
        printTamGiacSoNguoc(h, x);
    }else{
        printf("Chieu cao va cong sai khong thoa man\n");
    }
    return 0;
}
