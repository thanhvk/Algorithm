//
//  main.cpp
//  labiec14
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void printSum(int n){
    if (n%2 == 0) {
        printf("So luong:%d\n", n/2 - 1);
        
    }else{
        printf("So luong:%d\n", n/2);
        
    }
    
    for (int i = 1; i <= n/2; i ++) {
        if (i != n - i) {
            printf("%d + %d = %d\n\n", i, n - i, n);
            
        }
    }
}

int main(int argc, const char * argv[]) {
    printf("Nhap vao 1 so:\n");
    int n;
    scanf("%d", &n);
    printSum(n);
    return 0;
}
