//
//  main.cpp
//  labiecx
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void printButterfly(int h){
    if (h > 1 && h % 2 == 1) {
        for (int i = 0; i < h; i ++) {
            for (int j = 0; j < h; j ++) {
                if (i <= (h -1)/2) {
                    if (j > i && j < h - i - 1) {
                        printf(" ");
                    }else{
                        printf("*");
                    }
                    
                }else{
                    if (j + i > h - 1 && j < i) {
                        printf(" ");
                    }else{
                        printf("*");
                    }
                }
            }
            printf("\n");
        }
        
    }else{
        printf("Chieu cao phai lon hon  1 va la so le\n");
    }
}
int main(int argc, const char * argv[]) {
    printf("Nhap vao chieu cao:\n");
    int h;
    scanf("%d", &h);
    printf("\n");
    printButterfly(h);
    return 0;
}
