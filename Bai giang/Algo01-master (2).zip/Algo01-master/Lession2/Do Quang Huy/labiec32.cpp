//
//  main.cpp
//  labiec32
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void printX(int h){
    if (h > 0 && h %2 == 1) {
        int number = h;
        for (int i = 0; i < h; i ++) {
            for (int j = 0; j < h; j ++) {
                if (j - i == 0 || j + i == h - 1) {
                    printf("%d", number);
                }else{
                    printf(" ");
                }
            }
            number -= 1;
            printf("\n");
        }
    }else{
        printf("Chieu cao phai lon hon 0 va la so le\n");
    }
}

int main(int argc, const char * argv[]) {
    printf("Nhap vao chieu cao:\n");
    int h;
    scanf("%d", &h);
    printf("\n");
    printX(h);
    return 0;
}
