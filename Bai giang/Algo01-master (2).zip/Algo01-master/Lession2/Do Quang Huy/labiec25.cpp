//
//  main.cpp
//  labiec25
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void checkCapSoCong(int n){
    if (n > 1) {
        int k = 0;
        int congSai = 0;
        bool isCapSoCong = true;
        for (int i = 0; i < n; i ++) {
            int j;
            printf("Nhap so:\n");
            scanf("%d", &j);
            int temp = congSai;
            congSai = j - k;
            k = j;
            
            if (congSai != temp && i > 1) {
                isCapSoCong = false;
            }
        }
        if (isCapSoCong) {
            printf("La cap so cong\n");
        }else{
            printf("Khong la cap so cong\n");
        }

    }else{
        printf("Day so phai it nhat 2 so trong day");
    }
    printf("---------------\n");

}

int main(int argc, const char * argv[]) {
    while (true) {
        printf("Nhap so cac so trong day:\n");
        int n;
        scanf("%d", &n);
        checkCapSoCong(n);
    }
    return 0;
}
