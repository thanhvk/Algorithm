//
//  main.cpp
//  labiec35
//
//  Created by Quang Huy on 3/21/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
bool checkSuPhuHop(int h, int w, int d){
    if (h <= 1 || w <= 1 || d <= 1) {
        return false;
    }
    return true;
}
void printHangRao(int h, int w, int d){
    int start = 0;
    for (int i = 0; i < h; i ++) {
        for (int j = 0; j < w; j ++) {
            if (j == 0 || j == start || i == h - 1) {
                printf("*");
                start += d;
            }else{
                printf(" ");
            }
        }
        start = 0;
        printf("\n");
    }
}
int main(int argc, const char * argv[]) {
    printf("Nhap chieu cao:\n");
    int h;
    scanf("%d", &h);
    printf("Nhap chieu rong:\n");
    int w;
    scanf("%d", &w);
    printf("Nhap khoang cach:\n");
    int d;
    scanf("%d", &d);
    printf("\n");
    bool isOK = checkSuPhuHop(h, w, d);
    if (isOK) {
        printHangRao(h, w, d);
    }else{
        printf("Thong so nhap vao khong thoa man\n");
    }
    return 0;

}
