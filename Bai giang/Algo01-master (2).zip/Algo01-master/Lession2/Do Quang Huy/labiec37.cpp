//
//  main.cpp
//  labiec37
//
//  Created by Quang Huy on 3/21/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
//Hai số nguyên dương N và W nhập từ file (W lớn hơn 2 và là số lẻ).
bool check(int n, int w){
    if (n <= 0 || w <= 2 || w % 2 == 0) {
        return false;
    }
    return true;
}
void printHinhThoi(int n, int w){
    int middlePoint = (w - 1)/2;
    for (int i = 0; i < n * (w - 1) + 1; i ++) {
        int k = i / (w - 1) + 1;
        int multiple = k *middlePoint;
        for (int j = 0; j < w; j ++) {
            if (i <= 2*multiple - middlePoint && (j == 2*multiple - middlePoint - i|| j == i + 3*middlePoint - 2*multiple)){
                printf("*");
            }else if(i >  2*multiple - middlePoint && (j == i - 2*multiple + middlePoint || j == 2*multiple + middlePoint - i)){
                printf("*");
            }else{
                printf(" ");
            }
        }
        printf("\n");
    }
}
int main(int argc, const char * argv[]) {
    int n, w;
    printf("Nhap vao chieu rong:\n");
    scanf("%d", &w);
    printf("Nhap vao so hinh thoi:\n");
    scanf("%d", &n);
    printf("\n");
    bool isOK = check(n, w);
    if (isOK) {
        printHinhThoi(n, w);
    }else{
        printf("Chieu rong hoac so hinh thoi chua chinh xac");
    }
    return 0;
}
