//
//  main.cpp
//  labiec26
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void checkAmDuong(int n){
    if (n > 1 && n < 100) {
        int a[n];
        for (int i = 0; i < n; i++) {
            printf("Nhap phan tu trong day:\n");
            scanf("%d", &a[i]);
        }
        bool isChuoiAmDuong = true;
        for (int i = 0; i < n - 1; i ++) {
            if (a[i + 1] * a[i] >= 0) {
                isChuoiAmDuong = false;
            }
        }
        
        printf("Ket qua:\n");

        if (isChuoiAmDuong) {
            printf("1\n");
        }else{
            printf("0\n");
        }
        printf("-----------------------------\n");

    }else{
        printf("Day so phai lon hon 1 va nho hon 100 phan tu");
    }
}

int main(int argc, const char * argv[]) {
    while (true) {
        printf("Nhap so phan tu trong day:\n");
        int n;
        scanf("%d", &n);
        checkAmDuong(n);
    }
    return 0;
}
