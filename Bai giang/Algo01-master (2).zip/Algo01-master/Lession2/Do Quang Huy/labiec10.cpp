//
//  main.cpp
//  labiec10
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
//Viết chương trình tìm ước số chung lớn nhất và bội số chung nhỏ nhất của 2 số nguyên dương a và b (0<a,b<=100)
void printUSCLNandBSCNN(int a, int b){
    if (a > 0 && b > 0 && a <= 100 && b <= 100) {
        int min;
        if (a>=b) {
            min = b;
        }else{
            min = a;
        }
        
        int maxFactor = 1;
        for (int i = 1; i <= min; i ++) {
            if (a % i == 0 && b % i == 0) {
                if (i > maxFactor) {
                    maxFactor = i;
                }
            }
        }
        printf("Uoc so chung lon nhat:%d\n", maxFactor);
        int minMulti = (a * b)/maxFactor;
        printf("Boi so chung nho nhat:%d\n", minMulti);
    }else{
        printf("Moi nhap lai 2 so nguyen duong khong lon hon 100");
    }
}
int main(int argc, const char * argv[]) {
    int a, b;
    printf("Nhap vao  so thu nhat:\n");
    scanf("%d", &a);
    printf("Nhap vao  so thu hai:\n");
    scanf("%d", &b);
    printUSCLNandBSCNN(a, b);
    return 0;
}
