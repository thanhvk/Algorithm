//
//  main.cpp
//  labiec38
//
//  Created by Quang Huy on 3/21/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
bool check(int n, int w){
    if (n <= 0 || w <= 2) {
        return false;
    }
    return true;
}
void printZ(int n, int w){
    int start = 0;
    bool isMatch = false;
    int count = 0;
    for (int i = 0; i < n * (w - 1) + 1; i++) {
        for (int j = 0; j < w; j ++) {
            if (i == start) {
                printf("%d", count);
                count++;
                if (count > 9) {
                    count = 0;
                }
                isMatch = true;
            }else if (i + j == (w - 1) * (i/ (w - 1) + 1)){
                printf("%d", count);
                count++;
                if (count > 9) {
                    count = 0;
                }
            }else{
                printf(" ");
            }
        }
        if (isMatch) {
            start += w - 1;
            isMatch = false;
        }
        printf("\n");
    }
}

int main()
{
    int w, n;
    printf("Nhap vao chieu rong:\n");
    scanf("%d", &w);
    printf("Nhap vao so chu Z:\n");
    scanf("%d", &n);
    printf("\n");
    bool isOK = check(n, w);
    if (isOK) {
        printZ(n, w);
    }else{
        printf("Chieu rong hoac so chu can nhap khong dung\n");
    }
    return 0;
}
