//
//  main.cpp
//  labiec24
//
//  Created by Quang Huy on 3/20/16.
//  Copyright © 2016 Quang Huy. All rights reserved.
//

#include <iostream>
void printBangCuuChuong(){
    for (int i = 1; i <= 9; i ++) {
        for (int j = 1; j <= 9; j++) {
            printf("%4d", j * i);
        }
        printf("\n");
    }
}
int main(int argc, const char * argv[]) {
    printBangCuuChuong();
    return 0;
}
